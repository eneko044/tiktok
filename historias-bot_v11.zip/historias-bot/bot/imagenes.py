"""Generación de viñetas.

- bfl:    FLUX.2 en la API oficial de Black Forest Labs, con referencias visuales: primero dibuja una ficha
          de cada elemento que se repite (el protagonista y, como mucho, otros 2) y luego se la pasa a cada
          viñeta en la que sale, para que se vea igual en todo el vídeo.
- fal:    FLUX.1 en fal.ai, sin referencias.
- prueba: viñetas de muestra sin API, para probar el montaje gratis.
"""
import base64
import io
import json
import logging
import random
import shutil
import textwrap
import time
from pathlib import Path

import numpy as np
import requests
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from .config import CARPETA_FUENTES, clave
from .util import ErrorDefinitivo, comprobar_respuesta, con_reintentos, descargar, slug

log = logging.getLogger("historias")

URL_BFL = "https://api.bfl.ai/v1/"
MAX_REFERENCIAS = 4          # FLUX.2 [klein] admite hasta 4 imágenes de entrada
LADO_REFERENCIA = 768        # las referencias se envían reducidas: suficiente detalle y menos coste
EN_CURSO = {"Pending", "Reasoning", "Generating"}


class Moderado(ErrorDefinitivo):
    """BFL ha rechazado el texto o la imagen por su filtro de contenido."""


def generar_vinetas(historia: dict, cfg: dict, carpeta: Path) -> list[Path]:
    escenas = historia["escenas"]
    semilla = random.randint(1, 2**31 - 1)  # misma semilla en todo el vídeo = estilo más coherente
    if cfg["proveedor"] == "bfl":
        return _vinetas_bfl(historia, cfg, carpeta, semilla)
    rutas = []
    for i, escena in enumerate(escenas, 1):
        destino = carpeta / f"vineta_{i:02d}.png"
        if cfg["proveedor"] == "fal":
            _fal(escena["imagen"], cfg, semilla, destino)
        else:
            _muestra(escena, i, len(escenas), cfg, destino)
        rutas.append(destino)
        log.info("Viñeta %d/%d lista", i, len(escenas))
    return rutas


# ====================================================================== BFL (API oficial de FLUX)
def _vinetas_bfl(historia: dict, cfg: dict, carpeta: Path, semilla: int) -> list[Path]:
    escenas = historia["escenas"]
    estilo = cfg["estilo"]
    coste = {"creditos": 0.0, "imagenes": 0}
    usar_refs = cfg.get("referencias", True)
    usar_estilo = cfg.get("referencia_estilo", True)

    # 1) Fichas de referencia: el protagonista y los elementos que se repiten.
    fichas, nombres = {}, {}
    if usar_refs:
        for ref in historia.get("referencias", [])[:MAX_REFERENCIAS - 1]:
            destino = carpeta / f"ref_{slug(ref['id'], 30)}.png"
            prompt = _prompt_ficha(ref, estilo)
            try:
                _bfl(prompt, cfg, semilla, [], destino, coste, ancho=768, alto=768)
            except Moderado as e:
                log.warning("No se pudo dibujar la ficha de %s (%s). Se sigue sin ella.", ref["nombre"], e)
                continue
            fichas[ref["id"]] = destino
            nombres[ref["id"]] = ref["nombre"]
            log.info("Ficha de referencia lista: %s", ref["nombre"])

    # 2) Viñetas, cada una con las fichas de lo que sale en ella y la primera viñeta como guía de estilo.
    rutas: list[Path] = []
    for i, escena in enumerate(escenas, 1):
        destino = carpeta / f"vineta_{i:02d}.png"
        imagenes, frases = [], []
        for rid in escena.get("aparecen", []):
            if rid in fichas and len(imagenes) < MAX_REFERENCIAS:
                imagenes.append(fichas[rid])
                frases.append(f"{nombres[rid]} must look exactly as in image {len(imagenes)} "
                              f"(same appearance, colors, materials and proportions)")
        if usar_estilo and rutas and len(imagenes) < MAX_REFERENCIAS:
            imagenes.append(rutas[0])
            frases.append(f"match the art style, color palette and lighting of image {len(imagenes)}, "
                          f"but not its composition or content")
        prompt = f"{estilo}. {escena['imagen']}."
        if frases:
            prompt += " Consistency: " + "; ".join(frases) + "."
        try:
            _bfl(prompt, cfg, semilla, imagenes, destino, coste)
        except Moderado as e:
            # Segundo intento: sin referencias y con la escena suavizada.
            log.warning("BFL rechazó la viñeta %d (%s). Reintentando más suave.", i, e)
            try:
                _bfl(f"{estilo}. {escena['imagen']}. Implied, subtle and non-graphic, nothing explicit.",
                     cfg, semilla + i, [], destino, coste)
            except Moderado:
                if not rutas:
                    raise ErrorDefinitivo("BFL rechazó la primera viñeta dos veces. Cambia la historia o el estilo.")
                log.warning("Se reutiliza la viñeta anterior en la posición %d.", i)
                shutil.copy2(rutas[-1], destino)
        rutas.append(destino)
        log.info("Viñeta %d/%d lista%s", i, len(escenas), f" ({len(imagenes)} referencias)" if imagenes else "")

    coste["dolares"] = round(coste["creditos"] / 100, 3)  # 1 crédito = 0,01 $
    (carpeta / "coste.json").write_text(json.dumps(coste, indent=2), encoding="utf-8")
    log.info("Coste de las viñetas: %.3f $ (%d imágenes)", coste["dolares"], coste["imagenes"])
    return rutas


def _prompt_ficha(ref: dict, estilo: str) -> str:
    base = (f"{estilo}. Character and prop reference sheet for a comic. {ref['descripcion']}. "
            "Single subject, centered, fully visible, plain dark background, clear even lighting, "
            "nothing else in the frame")
    if ref["id"] == "protagonista":
        base += ", full body seen from behind in a three-quarter back view, face not visible"
    return base + "."


_PREFIJO_B64 = [""]  # "" = base64 sin más; si BFL lo rechaza se prueba con "data:image/jpeg;base64,"


def _b64(ruta: Path) -> str:
    img = Image.open(ruta).convert("RGB")
    img.thumbnail((LADO_REFERENCIA, LADO_REFERENCIA))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=88)
    return _PREFIJO_B64[0] + base64.b64encode(buf.getvalue()).decode("ascii")


def _cabeceras() -> dict:
    return {"x-key": clave("BFL_API_KEY"), "accept": "application/json"}


def _bfl(prompt: str, cfg: dict, semilla: int, referencias: list[Path], destino: Path, coste: dict,
         ancho: int | None = None, alto: int | None = None) -> None:
    modelo = cfg.get("modelo_bfl", "flux-2-klein-4b")

    def _cuerpo() -> dict:
        cuerpo = {"prompt": prompt, "width": ancho or cfg["ancho"], "height": alto or cfg["alto"],
                  "seed": semilla, "output_format": "png",
                  "safety_tolerance": int(cfg.get("tolerancia", 2))}
        for n, ruta in enumerate(referencias[:MAX_REFERENCIAS]):
            cuerpo["input_image" if n == 0 else f"input_image_{n + 1}"] = _b64(ruta)
        return cuerpo

    def _intento():
        r = requests.post(URL_BFL + modelo, headers=_cabeceras(), json=_cuerpo(), timeout=120)
        if r.status_code in (400, 422) and referencias and "image" in r.text.lower() and not _PREFIJO_B64[0]:
            _PREFIJO_B64[0] = "data:image/jpeg;base64,"
            r = requests.post(URL_BFL + modelo, headers=_cabeceras(), json=_cuerpo(), timeout=120)
        if r.status_code == 401 or r.status_code == 403:
            raise ErrorDefinitivo("BFL rechaza la clave. Cópiala otra vez de https://dashboard.bfl.ai")
        if r.status_code == 402:
            raise ErrorDefinitivo("Te has quedado sin créditos en BFL. Recarga en https://dashboard.bfl.ai")
        if r.status_code == 422:
            raise ErrorDefinitivo(f"BFL no acepta la petición: {r.text[:400]}")
        if r.status_code == 429:
            time.sleep(10)
        comprobar_respuesta(r)
        datos = r.json()
        url = _esperar(datos["polling_url"])
        descargar(url, destino)  # el enlace caduca a los 10 minutos: se descarga en cuanto está lista
        coste["creditos"] += float(datos.get("cost") or 0)
        coste["imagenes"] += 1

    con_reintentos(_intento, intentos=3, espera=8, descripcion="Viñeta en BFL")


def _esperar(polling_url: str, limite: float = 300) -> str:
    inicio = time.time()
    while time.time() - inicio < limite:
        time.sleep(1.0)
        r = requests.get(polling_url, headers=_cabeceras(), timeout=60)
        if r.status_code == 429:
            time.sleep(5)
            continue
        comprobar_respuesta(r)
        d = r.json()
        estado = d.get("status")
        if estado == "Ready":
            return d["result"]["sample"]
        if estado in EN_CURSO:
            continue
        if estado in ("Request Moderated", "Content Moderated"):
            motivos = (d.get("details") or {}).get("Moderation Reasons") or d.get("details") or ""
            raise Moderado(f"{estado} {motivos}".strip())
        raise RuntimeError(f"BFL devolvió «{estado}»: {d.get('details') or ''}")
    raise RuntimeError("BFL tardó más de 5 minutos en dibujar la viñeta.")


def saldo_bfl() -> float:
    """Créditos que te quedan en BFL (1 crédito = 0,01 $)."""
    r = requests.get(URL_BFL + "credits", headers=_cabeceras(), timeout=30)
    if r.status_code in (401, 403):
        raise ErrorDefinitivo("BFL rechaza la clave.")
    comprobar_respuesta(r)
    return float(r.json()["credits"])


def _fal(descripcion: str, cfg: dict, semilla: int, destino: Path) -> None:
    prompt = f"{cfg['estilo']}. {descripcion}"

    def _peticion():
        r = requests.post(
            f"https://fal.run/{cfg['modelo']}",
            headers={"Authorization": f"Key {clave('FAL_KEY')}"},
            json={
                "prompt": prompt,
                "image_size": {"width": cfg["ancho"], "height": cfg["alto"]},
                "seed": semilla,
                "num_images": 1,
                "enable_safety_checker": True,
                "output_format": "png",
            },
            timeout=300,
        )
        comprobar_respuesta(r)
        return r.json()["images"][0]["url"]

    url = con_reintentos(_peticion, descripcion="Generación de viñeta")
    descargar(url, destino)


def _muestra(escena: dict, n: int, total: int, cfg: dict, destino: Path) -> None:
    """Viñeta de prueba atmosférica (para probar el montaje sin gastar en la API de imágenes)."""
    w, h = cfg["ancho"], cfg["alto"]
    rng = np.random.default_rng(n * 7919)
    y = np.linspace(0, 1, h)[:, None]
    x = np.linspace(0, 1, w)[None, :]
    cx, cy = rng.uniform(0.3, 0.7), rng.uniform(0.25, 0.55)
    luz = np.exp(-(((x - cx) * 1.6) ** 2 + ((y - cy) * 1.1) ** 2) * 4.0)
    base = np.stack([0.05 + 0.20 * luz, 0.09 + 0.30 * luz, 0.11 + 0.28 * luz], axis=-1)
    base += rng.normal(0, 0.025, (h, w, 1))
    img = Image.fromarray((np.clip(base, 0, 1) * 255).astype("uint8"))
    d = ImageDraw.Draw(img)
    # Siluetas simples: suelo, un marco de puerta y una figura de espaldas.
    d.rectangle([0, int(h * 0.78), w, h], fill=(8, 10, 12))
    px = int(w * rng.uniform(0.15, 0.55))
    d.rectangle([px, int(h * 0.30), px + int(w * 0.30), int(h * 0.78)], outline=(20, 24, 26), width=18)
    fx = int(w * rng.uniform(0.35, 0.75))
    d.ellipse([fx - 38, int(h * 0.50), fx + 38, int(h * 0.56)], fill=(6, 7, 8))
    d.rounded_rectangle([fx - 70, int(h * 0.555), fx + 70, int(h * 0.80)], radius=40, fill=(6, 7, 8))
    img = img.filter(ImageFilter.GaussianBlur(1.2))
    d = ImageDraw.Draw(img)
    d.rectangle([14, 14, w - 15, h - 15], outline=(235, 225, 200), width=6)
    try:
        f_grande = ImageFont.truetype(str(CARPETA_FUENTES / "Anton-Regular.ttf"), 64)
        f_peque = ImageFont.truetype(str(CARPETA_FUENTES / "Anton-Regular.ttf"), 26)
    except OSError:
        f_grande = f_peque = ImageFont.load_default()
    d.text((40, 40), f"VIÑETA {n}/{total} · MUESTRA", font=f_peque, fill=(235, 200, 120))
    texto = "\n".join(textwrap.wrap("FLUX: " + escena["imagen"], 52)[:6])
    d.multiline_text((40, h - 250), texto, font=f_peque, fill=(200, 205, 205), spacing=6)
    d.text((40, 80), "AQUÍ IRÁ LA ILUSTRACIÓN", font=f_grande, fill=(240, 236, 225))
    img.save(destino)
