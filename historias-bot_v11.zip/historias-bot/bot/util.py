"""Utilidades comunes: peticiones con reintentos y ejecución de ffmpeg."""
import logging
import re
import shutil
import subprocess
import time
import unicodedata
from pathlib import Path

import requests

log = logging.getLogger("historias")


class ErrorDefinitivo(RuntimeError):
    """Error que no se arregla reintentando (clave mala, sin saldo, contenido rechazado...)."""


def con_reintentos(funcion, intentos: int = 4, espera: float = 5.0, descripcion: str = ""):
    """Ejecuta `funcion()` reintentando con espera creciente si falla."""
    ultimo_error = None
    for n in range(1, intentos + 1):
        try:
            return funcion()
        except ErrorDefinitivo:
            raise
        except Exception as e:  # noqa: BLE001 - queremos reintentar ante cualquier fallo de red/API
            ultimo_error = e
            if n < intentos:
                log.warning("%s falló (intento %d/%d): %s", descripcion or "Operación", n, intentos, e)
                time.sleep(espera * n)
    raise RuntimeError(f"{descripcion or 'Operación'} falló tras {intentos} intentos: {ultimo_error}")


def comprobar_respuesta(r: requests.Response) -> requests.Response:
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:500]}")
    return r


def descargar(url: str, destino: Path) -> Path:
    def _bajar():
        r = comprobar_respuesta(requests.get(url, timeout=120))
        destino.write_bytes(r.content)
        return destino
    return con_reintentos(_bajar, descripcion=f"Descarga de {destino.name}")


def ffmpeg(args: list, cwd: Path | None = None) -> None:
    """Ejecuta ffmpeg y muestra el error de forma legible si falla."""
    if not shutil.which("ffmpeg"):
        raise RuntimeError("No se encuentra ffmpeg. Instálalo y asegúrate de que está en el PATH.")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)]
    res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError("ffmpeg falló:\n" + res.stderr[-2000:])


def duracion_audio(ruta: Path) -> float:
    import soundfile as sf
    info = sf.info(str(ruta))
    return info.frames / info.samplerate


def slug(texto: str, largo: int = 40) -> str:
    texto = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode()
    texto = re.sub(r"[^a-zA-Z0-9]+", "-", texto).strip("-").lower()
    return texto[:largo] or "historia"
