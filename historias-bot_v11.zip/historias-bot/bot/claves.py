"""Lectura y guardado de las claves del archivo .env desde el panel (nunca se devuelven completas)."""
import os

from .config import RAIZ

RUTA = RAIZ / ".env"

# (nombre, servicio, qué es, es secreta, dónde conseguirla, grupo)
CLAVES = [
    ("OPENAI_API_KEY", "OpenAI", "Escribe las historias", True, "https://platform.openai.com/api-keys", "produccion"),
    ("BFL_API_KEY", "FLUX (BFL)", "Dibuja las viñetas", True, "https://dashboard.bfl.ai", "bfl"),
    ("FAL_KEY", "fal.ai", "Dibuja las viñetas", True, "https://fal.ai/dashboard/keys", "fal"),
    ("BUFFER_API_KEY", "Buffer", "Programa las publicaciones", True, "https://publish.buffer.com/settings/api", "buffer"),
    ("CLOUDINARY_CLOUD_NAME", "Cloudinary", "Nombre de la nube", False, "https://console.cloudinary.com", "buffer"),
    ("CLOUDINARY_API_KEY", "Cloudinary", "Clave de API", True, "https://console.cloudinary.com", "buffer"),
    ("CLOUDINARY_API_SECRET", "Cloudinary", "Secreto de API", True, "https://console.cloudinary.com", "buffer"),
    ("UPLOAD_POST_API_KEY", "Upload-Post", "Clave de API", True, "https://app.upload-post.com", "upload_post"),
    ("UPLOAD_POST_USER", "Upload-Post", "Nombre del perfil", False, "https://app.upload-post.com", "upload_post"),
]
NOMBRES = {c[0] for c in CLAVES}


def _leer_archivo() -> dict:
    valores = {}
    if RUTA.exists():
        for linea in RUTA.read_text(encoding="utf-8").splitlines():
            s = linea.strip()
            if s and not s.startswith("#") and "=" in s:
                k, v = s.split("=", 1)
                valores[k.strip()] = v.strip().strip('"').strip("'")
    return valores


def leer() -> list[dict]:
    archivo = _leer_archivo()
    lista = []
    for nombre, servicio, que, secreta, url, grupo in CLAVES:
        valor = archivo.get(nombre) or os.environ.get(nombre, "")
        if not valor:
            muestra = ""
        elif secreta:
            muestra = f"…{valor[-4:]}" if len(valor) > 8 else "guardada"
        else:
            muestra = valor
        lista.append({"nombre": nombre, "servicio": servicio, "que": que, "secreta": secreta, "url": url,
                      "grupo": grupo, "configurada": bool(valor), "muestra": muestra})
    return lista


def guardar(nuevos: dict) -> None:
    """Escribe solo las claves que llegan con valor; las demás se quedan como estaban."""
    nuevos = {k: str(v).strip() for k, v in nuevos.items() if k in NOMBRES and str(v).strip()}
    for k, v in nuevos.items():
        if any(c in v for c in "\r\n"):
            raise ValueError(f"La clave {k} tiene saltos de línea. Cópiala otra vez.")
    lineas = RUTA.read_text(encoding="utf-8").splitlines() if RUTA.exists() else [
        "# Claves de Historias Bot. No compartas este archivo con nadie."]
    pendientes = dict(nuevos)
    for i, linea in enumerate(lineas):
        s = linea.strip()
        if "=" in s and not s.startswith("#"):
            k = s.split("=", 1)[0].strip()
            if k in pendientes:
                lineas[i] = f"{k}={pendientes.pop(k)}"
    lineas += [f"{k}={v}" for k, v in pendientes.items()]
    RUTA.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    os.environ.update(nuevos)
