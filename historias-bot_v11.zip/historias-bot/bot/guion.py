"""Escritura de historias en primera persona, con gancho y tensión, y ranking de las mejores."""
import json
import logging
import random

import requests

from . import historial
from .config import cargar_config, clave
from .util import comprobar_respuesta, con_reintentos, slug

log = logging.getLogger("historias")

URL_OPENAI = "https://api.openai.com/v1/chat/completions"

PROMPT_ESCRITOR = """Eres guionista de un canal de TikTok de relatos de terror y misterio narrados en primera persona,
estilo confesión a media luz. Cada vídeo dura entre un minuto y diez segundos y un minuto y medio, y se ilustra
como un cómic: una viñeta por escena.

QUIÉN HABLA
- Narra {narrador}. Siempre en primera persona y en español de España, natural, sin palabras rebuscadas.
- Tiene que sonar a alguien contando algo que le pasó de verdad y que todavía le revuelve: detalles concretos
  (una hora exacta, un olor, un ruido, una frase que alguien dijo), nada de descripciones genéricas.

ESTRUCTURA (es lo que hace que la gente no deslice)
1. GANCHO (escena 1): la primera frase, de 12 palabras como máximo, tiene que atrapar en 2 segundos.
   Empieza por una confesión, una regla inquietante o un detalle imposible. Prohibido: "Hola", "En este vídeo",
   "Os voy a contar", "Esta historia". Ejemplos de tono: "Nunca le he contado a nadie por qué dejé ese trabajo."
   / "Mi abuela tenía una norma: a las tres, las persianas bajadas."
2. TENSIÓN (escenas centrales): frases cortas. Cada escena sube un poco más. Usa silencios con puntos
   suspensivos (...) para que la voz haga pausas. Que el oyente intuya antes que vea.
   En un minuto la gente se va a mitad: hacia la mitad del relato mete un segundo gancho, una frase que
   prometa algo peor ("Pero eso no fue lo que me hizo irme." / "Y entonces encontré la nota.").
3. GIRO FINAL (última escena): una frase corta que cambie todo o deje una pregunta abierta y obligue a
   volver a ver el vídeo. Nada de moralejas ni explicaciones.

LÍMITES
- Ficción inspirada en leyendas y sucesos típicos; sin nombres ni apellidos de personas reales, sin direcciones
  reales, sin acusar a nadie real. Lugares genéricos ("un hotel de carretera en Soria") están bien.
- Inquietante, no sangriento: nada de gore, violencia explícita, menores en peligro ni autolesiones.
- No repitas ni te parezcas a estas historias ya publicadas: {usadas}

TAREA
Escribe UNA historia nueva sobre este tema: {subgenero}
- Entre {emin} y {emax} escenas y entre {pmin} y {pmax} palabras narradas en total. La historia decide la
  longitud: si tiene recorrido, usa la parte alta; si es más directa, la baja. Nunca rellenes con paja:
  cada escena tiene que añadir un detalle nuevo o subir la tensión.
- LONGITUD, MUY IMPORTANTE: cada escena tiene 2 o 3 frases, unas {ppe} palabras. Es más larga de lo que parece:
  antes de responder cuenta las palabras de todas las escenas, y si no llegas a {pmin}, añade escenas o detalles
  concretos (lo que oyó, lo que olía, lo que pensó en ese momento).
- Para cada escena, además del texto narrado, describe EN INGLÉS la viñeta (qué se ve, plano, luz).
  El narrador no muestra la cara: de espaldas, en sombra, sus manos, o lo que él ve en primera persona.

LO QUE TIENE QUE VERSE IGUAL EN TODAS LAS VIÑETAS
Las viñetas se dibujan por separado, así que antes se dibuja una ficha de referencia de cada elemento que se repite.
- En "referencias" pon siempre al protagonista, con id "protagonista". Si no hay motivo para otra cosa, es: {personaje}
- Añade como mucho otros 2 elementos que salgan en 2 o más viñetas y que tengan que reconocerse: un lugar
  concreto, un objeto clave o un segundo personaje que salgan en ESTA historia.
  No pongas cosas que salen una sola vez ni cosas genéricas (la noche, la lluvia).
- Para cada uno: "id" corto sin espacios ni tildes; "nombre" corto en inglés, que es como lo llamarás en las
  viñetas (por ejemplo "the narrator"); y "descripcion" en inglés, concreta y visual: forma,
  ropa, colores, materiales, edad, detalles que lo hagan inconfundible.
- En cada escena, "aparecen" es la lista de ids que salen en esa viñeta (vacía si no sale ninguno).
  En la descripción de la viñeta, llama a cada elemento por su "nombre" exacto.

Responde SOLO con este JSON:
{{
  "titulo": "título interno corto",
  "premisa": "una frase que resuma la historia (para no repetirla en el futuro)",
  "subgenero": "{subgenero}",
  "referencias": [{{"id": "protagonista", "nombre": "the narrator", "descripcion": "..."}}],
  "escenas": [{{"texto": "lo que dice el narrador", "imagen": "panel description in English", "aparecen": ["protagonista"]}}],
  "caption": "texto del post, máximo 120 caracteres, que deje intriga (sin hashtags)",
  "titulo_youtube": "título para YouTube Shorts, máximo 70 caracteres",
  "hashtags": ["#...", "#...", "#..."]
}}
HASHTAGS: exactamente 3, en español, sobre el tema concreto de ESTA historia, como los buscaría alguien en TikTok
(#hotelembrujado, #turnodenoche, #paralisisdelsueño). Sin tildes raras ni espacios. Nada de genéricos como #fyp,
#viral o #parati, y no repitas estos, que ya se añaden siempre: {fijos}"""

PROMPT_CRITICO = """Eres el editor de un canal de relatos de terror en TikTok. Puntúa cada historia del 1 al 10
pensando en cuánta gente se quedaría a verla entera: peso del gancho (primeros 2 segundos), tensión,
y si el final obliga a volver a verla. Sé exigente y no des empates si puedes evitarlo.

Historias:
{lista}

Responde SOLO con JSON: {{"puntuaciones": [{{"id": 0, "nota": 7.5, "motivo": "breve"}}]}}"""

PROMPT_AJUSTE = """Esta es una historia para un vídeo de terror narrado en primera persona. Tiene {n} palabras narradas
y necesita entre {pmin} y {pmax} (lo ideal, unas {objetivo}).
{instruccion}
Mantén el mismo gancho inicial, el mismo giro final, el mismo tono y las mismas "referencias". Cada escena nueva lleva
su "texto", su "imagen" en inglés y su lista "aparecen". En total, entre {emin} y {emax} escenas.
Devuelve SOLO el JSON completo, con exactamente el mismo formato.

{historia}"""

ALARGAR = ("Alárgala: añade escenas en medio con detalles concretos que suban la tensión (lo que oyó, lo que olía, lo que "
           "pensó en ese momento) y alarga las escenas que solo tienen una frase corta. Nada de paja ni ideas repetidas.")
ACORTAR = "Acórtala: quita lo que no aporte tensión y junta escenas si hace falta."

PERSONAJE = ("a man in his early thirties, slim build, dark grey hoodie, black jeans, short dark messy hair, "
             "always seen from behind, in silhouette or as first-person hands")


def _normalizar_referencias(h: dict) -> None:
    """Deja las referencias en un formato seguro: protagonista primero, como mucho 3, ids conocidos."""
    refs, vistos = [], set()
    for r in h.get("referencias") or []:
        if not isinstance(r, dict):
            continue
        rid = slug(str(r.get("id", "")), 30).replace("-", "_")
        if not rid or rid in vistos or not r.get("descripcion"):
            continue
        vistos.add(rid)
        refs.append({"id": rid, "nombre": str(r.get("nombre") or rid.replace("_", " ")).strip(),
                     "descripcion": str(r["descripcion"]).strip()})
    if "protagonista" not in vistos:
        refs.insert(0, {"id": "protagonista", "nombre": "the narrator", "descripcion": PERSONAJE})
    refs.sort(key=lambda r: r["id"] != "protagonista")
    refs = refs[:3]
    ids = {r["id"] for r in refs}
    for e in h["escenas"]:
        aparecen = e.get("aparecen") or []
        if not isinstance(aparecen, list):
            aparecen = []
        limpios = []
        for a in aparecen:
            a = slug(str(a), 30).replace("-", "_")
            if a in ids and a not in limpios:
                limpios.append(a)
        e["aparecen"] = limpios
    h["referencias"] = refs


def _llamar(modelo: str, prompt: str) -> dict:
    def _peticion():
        r = requests.post(
            URL_OPENAI,
            headers={"Authorization": f"Bearer {clave('OPENAI_API_KEY')}"},
            json={
                "model": modelo,
                "messages": [{"role": "user", "content": prompt}],
                "response_format": {"type": "json_object"},
            },
            timeout=180,
        )
        comprobar_respuesta(r)
        return json.loads(r.json()["choices"][0]["message"]["content"])
    return con_reintentos(_peticion, descripcion="Llamada al modelo de texto")


def _palabras(historia: dict) -> int:
    return sum(len(e["texto"].split()) for e in historia["escenas"])


def _valida(h: dict, cfg: dict) -> str | None:
    """Devuelve el motivo si la historia no sirve, o None si es válida."""
    try:
        if not cfg["escenas_min"] - 1 <= len(h["escenas"]) <= cfg["escenas_max"] + 1:
            return f"tiene {len(h['escenas'])} escenas"
        n = _palabras(h)
        if not cfg["palabras_min"] - 10 <= n <= cfg["palabras_max"] + 15:
            return f"tiene {n} palabras"
        if not all(e.get("texto") and e.get("imagen") for e in h["escenas"]):
            return "escenas incompletas"
        if historial.es_repetida(h["premisa"]):
            return "se parece a una ya publicada"
    except (KeyError, TypeError):
        return "JSON incompleto"
    return None


def _ajustar_longitud(cfg_guion: dict, h: dict) -> dict:
    """Pide al modelo que alargue o acorte la historia hasta el rango de palabras."""
    n = _palabras(h)
    prompt = PROMPT_AJUSTE.format(
        n=n, pmin=cfg_guion["palabras_min"], pmax=cfg_guion["palabras_max"],
        objetivo=(cfg_guion["palabras_min"] + cfg_guion["palabras_max"]) // 2,
        instruccion=ALARGAR if n < cfg_guion["palabras_min"] else ACORTAR,
        emin=cfg_guion["escenas_min"], emax=cfg_guion["escenas_max"],
        historia=json.dumps(h, ensure_ascii=False),
    )
    return _llamar(cfg_guion["modelo"], prompt)


def _longitud_mal(h: dict, cfg: dict) -> bool:
    try:
        n = _palabras(h)
    except (KeyError, TypeError):
        return False
    return not cfg["palabras_min"] - 10 <= n <= cfg["palabras_max"] + 15


def escribir_historia(cfg_guion: dict, subgenero: str, usadas: list[dict]) -> dict:
    lista_usadas = "; ".join(f"«{u['premisa']}»" for u in usadas[:60]) or "ninguna todavía"
    escenas_medias = (cfg_guion["escenas_min"] + cfg_guion["escenas_max"]) / 2
    prompt = PROMPT_ESCRITOR.format(
        narrador=cfg_guion["narrador"], usadas=lista_usadas, subgenero=subgenero,
        emin=cfg_guion["escenas_min"], emax=cfg_guion["escenas_max"],
        pmin=cfg_guion["palabras_min"], pmax=cfg_guion["palabras_max"],
        ppe=round((cfg_guion["palabras_min"] + cfg_guion["palabras_max"]) / 2 / escenas_medias),
        personaje=PERSONAJE, fijos=" ".join(cargar_config()["publicacion"].get("hashtags_fijos", [])) or "ninguno",
    )
    for intento in range(3):
        h = _llamar(cfg_guion["modelo"], prompt)
        # Los modelos pequeños suelen quedarse cortos: en vez de tirar la historia, se le pide que la ajuste.
        for _ in range(2):
            if not _longitud_mal(h, cfg_guion):
                break
            log.info("La historia tiene %d palabras; pidiendo que la ajuste...", _palabras(h))
            try:
                ajustada = _ajustar_longitud(cfg_guion, h)
                if ajustada.get("escenas"):
                    ajustada.setdefault("referencias", h.get("referencias"))
                    h = ajustada
            except Exception as e:  # noqa: BLE001
                log.warning("No se pudo ajustar la longitud: %s", e)
                break
        problema = _valida(h, cfg_guion)
        if problema is None:
            h["subgenero"] = subgenero
            _normalizar_referencias(h)
            log.info("Referencias visuales: %s", ", ".join(r["nombre"] for r in h["referencias"]))
            return h
        log.warning("Historia descartada (%s), reescribiendo...", problema)
    raise RuntimeError(f"No se consiguió una historia válida sobre: {subgenero}")


def elegir_subgeneros(cfg_guion: dict, n: int) -> list[str]:
    """Reparte temas evitando los usados en los últimos vídeos."""
    todos = list(cfg_guion["subgeneros"])
    ultimos = set(historial.subgeneros_recientes(len(todos) // 2))
    frescos = [s for s in todos if s not in ultimos] or todos
    random.shuffle(frescos)
    elegidos = frescos[:n]
    while len(elegidos) < n:
        elegidos.append(random.choice(todos))
    return elegidos


def puntuar(cfg_guion: dict, historias: list[dict]) -> list[dict]:
    """Añade 'puntuacion' a cada historia y las devuelve ordenadas de mejor a peor."""
    lista = "\n\n".join(
        f"[id {i}] " + " ".join(e["texto"] for e in h["escenas"]) for i, h in enumerate(historias)
    )
    try:
        res = _llamar(cfg_guion["modelo"], PROMPT_CRITICO.format(lista=lista))
        notas = {int(p["id"]): float(p["nota"]) for p in res["puntuaciones"]}
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudo puntuar (%s); se mantiene el orden original.", e)
        notas = {}
    for i, h in enumerate(historias):
        h["puntuacion"] = notas.get(i, 5.0)
    return sorted(historias, key=lambda h: h["puntuacion"], reverse=True)


def generar_lote(cfg_guion: dict, cantidad: int, extra: int) -> list[dict]:
    """Escribe cantidad+extra historias distintas y devuelve las `cantidad` mejores, ordenadas."""
    usadas = historial.recientes(80)
    historias = []
    for subgenero in elegir_subgeneros(cfg_guion, cantidad + extra):
        try:
            h = escribir_historia(cfg_guion, subgenero, usadas + [{"premisa": x["premisa"]} for x in historias])
            historias.append(h)
            log.info("Historia escrita: %s (%d palabras)", h["titulo"], _palabras(h))
        except Exception as e:  # noqa: BLE001
            log.error("Fallo escribiendo sobre '%s': %s", subgenero, e)
    if not historias:
        raise RuntimeError("No se pudo escribir ninguna historia. Mira la pestaña Actividad para ver por qué.")
    if len(historias) < cantidad:
        log.warning("Solo salieron %d historias de %d: se publican las que hay, empezando por la mejor hora.",
                    len(historias), cantidad)
    return puntuar(cfg_guion, historias)[:cantidad]
