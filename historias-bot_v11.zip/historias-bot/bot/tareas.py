"""Las tareas del bot: producir vídeos, preparar el día, publicar, reintentar, limpiar y el ciclo automático.
Las usan tanto la terminal (main.py) como el panel."""
import json
import logging
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

from . import guion, historial, imagenes, montaje, publicar, voz
from .config import CARPETA_SALIDA, cargar_config, clave
from .util import slug

log = logging.getLogger("historias")

# Solo una tarea pesada a la vez (generar vídeos, publicar), venga del panel o del modo automático.
CERROJO = threading.Lock()


def producir_video(historia: dict, carpeta: Path, cfg: dict, proveedor_imagenes: str | None = None) -> Path:
    carpeta.mkdir(parents=True, exist_ok=True)
    (carpeta / "guion.json").write_text(json.dumps(historia, ensure_ascii=False, indent=2), encoding="utf-8")
    cfg_img = dict(cfg["imagenes"])
    if proveedor_imagenes:
        cfg_img["proveedor"] = proveedor_imagenes
    vinetas = imagenes.generar_vinetas(historia, cfg_img, carpeta)
    audio = voz.generar_voz(historia["escenas"], cfg["voz"], carpeta)
    return montaje.montar(vinetas, audio, cfg["video"], cfg["subtitulos"], carpeta)


def generar_prueba(cfg: dict, sin_apis: bool) -> dict:
    """Un vídeo completo que no se publica. Devuelve {'id', 'video', 'textos'}."""
    if sin_apis:
        from .ejemplo import HISTORIA_EJEMPLO
        historia, proveedor = HISTORIA_EJEMPLO, "prueba"
    else:
        tema = guion.elegir_subgeneros(cfg["guion"], 1)[0]
        historia = guion.escribir_historia(cfg["guion"], tema, historial.recientes())
        proveedor = None
    carpeta = CARPETA_SALIDA / "pruebas" / f"{datetime.now():%Y%m%d_%H%M%S}_{slug(historia['titulo'])}"
    video = producir_video(historia, carpeta, cfg, proveedor)
    return {
        "id": carpeta.relative_to(CARPETA_SALIDA).as_posix(),
        "video": str(video),
        "textos": publicar.textos(historia, cfg["publicacion"]),
    }


def huecos_pendientes(cfg: dict, ahora: datetime) -> list[dict]:
    """Horas de publicación de hoy que aún no han pasado y que todavía no tienen vídeo."""
    fecha = ahora.strftime("%Y-%m-%d")
    ya = {v["hora"] for v in historial.del_dia(fecha)}
    margen = timedelta(minutes=20)
    huecos = []
    for p in cfg["publicaciones"]:
        h, m = map(int, p["hora"].split(":"))
        momento = ahora.replace(hour=h, minute=m, second=0, microsecond=0)
        if momento > ahora + margen and p["hora"] not in ya:
            huecos.append(p)
    return huecos


def preparar_dia(cfg: dict, ahora: datetime) -> dict:
    """Escribe, produce y programa los vídeos de las horas que aún no han pasado hoy."""
    zona = cfg["zona_horaria"]
    fecha = ahora.strftime("%Y-%m-%d")
    huecos = huecos_pendientes(cfg, ahora)
    if not huecos:
        log.info("No quedan horas de publicación libres hoy (%s).", fecha)
        historial.marcar_lote(fecha)
        return {"preparados": 0}

    log.info("Preparando %d vídeos para %s", len(huecos), fecha)
    historias = guion.generar_lote(cfg["guion"], len(huecos), cfg.get("candidatos_extra", 2))
    # La mejor historia va a la hora con prioridad 1, la segunda a la 2, etc.
    huecos.sort(key=lambda p: p["prioridad"])
    hechos = 0
    for hueco, historia in zip(huecos, historias):
        hora = hueco["hora"]
        carpeta = CARPETA_SALIDA / fecha / f"{hora.replace(':', '')}_{slug(historia['titulo'])}"
        try:
            video = producir_video(historia, carpeta, cfg)
        except Exception as e:  # noqa: BLE001
            log.exception("Fallo produciendo '%s': %s", historia["titulo"], e)
            continue
        id_video = historial.registrar(historia, fecha, hora, hueco["prioridad"], str(video), "pendiente")
        publicar_registro(cfg, id_video, video, historia, fecha, hora, zona)
        hechos += 1
    historial.marcar_lote(fecha)
    return {"preparados": hechos}


def publicar_registro(cfg, id_video, video, historia, fecha, hora, zona) -> None:
    ahora = datetime.now(ZoneInfo(zona))
    programada = datetime.fromisoformat(f"{fecha}T{hora}").replace(tzinfo=ZoneInfo(zona))
    if programada < ahora + timedelta(minutes=3):
        # La hora ya pasó (PC encendido tarde o reintento): se publica en unos minutos.
        nueva = ahora + timedelta(minutes=5)
        fecha, hora = nueva.strftime("%Y-%m-%d"), nueva.strftime("%H:%M")
    try:
        detalle = publicar.publicar(Path(video), historia, fecha, hora, cfg["publicacion"], zona)
        estado = "listo_manual" if cfg["publicacion"]["modo"] == "manual" else "programado"
        historial.actualizar_estado(id_video, estado, detalle)
    except Exception as e:  # noqa: BLE001
        log.error("No se pudo publicar '%s': %s", historia["titulo"], e)
        historial.actualizar_estado(id_video, "error_publicacion", str(e))


def hay_reintentos(cfg: dict) -> bool:
    hoy = datetime.now(ZoneInfo(cfg["zona_horaria"])).strftime("%Y-%m-%d")
    return any(v["fecha_publicacion"] == hoy and Path(v["ruta_video"]).exists()
               for v in historial.pendientes_de_publicar())


def reintentar_publicaciones(cfg: dict) -> None:
    zona = cfg["zona_horaria"]
    hoy = datetime.now(ZoneInfo(zona)).strftime("%Y-%m-%d")
    for v in historial.pendientes_de_publicar():
        if v["fecha_publicacion"] != hoy or not Path(v["ruta_video"]).exists():
            continue
        log.info("Reintentando publicar '%s'", v["titulo"])
        publicar_registro(cfg, v["id"], v["ruta_video"], json.loads(v["guion"]), v["fecha_publicacion"], v["hora"], zona)


def limpiar_alojamiento(cfg: dict) -> None:
    """Borra de Cloudinary los vídeos que ya se publicaron (a partir del día siguiente) y los marca como publicados."""
    hoy = datetime.now(ZoneInfo(cfg["zona_horaria"])).strftime("%Y-%m-%d")
    from . import alojamiento
    for v in historial.programados_antes_de(hoy):
        try:
            datos = json.loads(v["detalle"] or "{}")
        except json.JSONDecodeError:
            datos = {}
        try:
            for a in datos.get("alojamiento", []):
                alojamiento.borrar(a)
            historial.actualizar_estado(v["id"], "publicado", v["detalle"] or "")
        except Exception as e:  # noqa: BLE001
            log.warning("No se pudo limpiar el alojamiento de '%s': %s", v["titulo"], e)


def toca_preparar(cfg: dict, ahora: datetime) -> bool:
    h, m = map(int, cfg["hora_generacion"].split(":"))
    return not historial.lote_hecho(ahora.strftime("%Y-%m-%d")) and (ahora.hour, ahora.minute) >= (h, m)


def faltan_claves_produccion() -> list[str]:
    """Claves sin las que no se puede producir un vídeo real."""
    cfg = cargar_config()
    faltan = []
    if not clave("OPENAI_API_KEY", obligatoria=False):
        faltan.append("OpenAI (guiones)")
    proveedor = cfg["imagenes"]["proveedor"]
    if proveedor == "bfl" and not clave("BFL_API_KEY", obligatoria=False):
        faltan.append("FLUX de BFL (viñetas)")
    if proveedor == "fal" and not clave("FAL_KEY", obligatoria=False):
        faltan.append("fal.ai (viñetas)")
    return faltan


def ciclo_servicio() -> None:
    """Modo 24/7 desde la terminal (sin panel)."""
    log.info("Servicio iniciado. Ctrl+C para parar.")
    ultimo_reintento = ultima_limpieza = 0.0
    while True:
        try:
            cfg = cargar_config()  # recarga por si cambias config.yaml sin reiniciar
            ahora = datetime.now(ZoneInfo(cfg["zona_horaria"]))
            with CERROJO:
                if toca_preparar(cfg, ahora):
                    preparar_dia(cfg, ahora)
                if time.time() - ultimo_reintento > 1800:
                    reintentar_publicaciones(cfg)
                    ultimo_reintento = time.time()
                if time.time() - ultima_limpieza > 3600:
                    limpiar_alojamiento(cfg)
                    ultima_limpieza = time.time()
        except KeyboardInterrupt:
            raise
        except Exception as e:  # noqa: BLE001 - el servicio no debe caerse nunca
            log.exception("Error en el ciclo del servicio: %s", e)
        time.sleep(60)


def comprobar_claves(cfg: dict) -> list[dict]:
    """Prueba las claves que se pueden comprobar sin gastar. ok: True, False o None (no se puede comprobar)."""
    res = []

    def poner(servicio, ok, mensaje):
        res.append({"servicio": servicio, "ok": ok, "mensaje": mensaje})

    k = clave("OPENAI_API_KEY", obligatoria=False)
    if not k:
        poner("OpenAI", False, "Falta la clave. Sin ella no se pueden escribir historias.")
    else:
        try:
            r = requests.get("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {k}"}, timeout=30)
            if r.status_code == 200:
                poner("OpenAI", True, "Clave válida.")
            elif r.status_code == 401:
                poner("OpenAI", False, "OpenAI rechaza la clave. Cópiala otra vez desde platform.openai.com.")
            else:
                poner("OpenAI", False, f"OpenAI respondió con un error {r.status_code}.")
        except requests.RequestException as e:
            poner("OpenAI", False, f"No se pudo conectar con OpenAI: {e}")

    if cfg["imagenes"]["proveedor"] == "bfl":
        if not clave("BFL_API_KEY", obligatoria=False):
            poner("FLUX (BFL)", False, "Falta la clave. Sin ella no se pueden dibujar las viñetas.")
        else:
            try:
                saldo = imagenes.saldo_bfl()
                vinetas = int(saldo / 1.4)
                poner("FLUX (BFL)", saldo > 0,
                      f"Clave válida. Saldo: {saldo:.0f} créditos ({saldo / 100:.2f} $), unas {vinetas} viñetas."
                      if saldo > 0 else "Clave válida, pero no te quedan créditos. Recarga en dashboard.bfl.ai.")
            except Exception as e:  # noqa: BLE001
                poner("FLUX (BFL)", False, str(e))
    if cfg["imagenes"]["proveedor"] == "fal":
        if clave("FAL_KEY", obligatoria=False):
            poner("fal.ai", None, "Clave guardada. Se comprobará al generar la primera viñeta.")
        else:
            poner("fal.ai", False, "Falta la clave. Sin ella no se pueden dibujar las viñetas.")

    modo = cfg["publicacion"]["modo"]
    if modo == "buffer":
        if not clave("BUFFER_API_KEY", obligatoria=False):
            poner("Buffer", False, "Falta la clave. Sin ella no se pueden programar las publicaciones.")
        else:
            try:
                from . import buffer
                encontrados = buffer.canales(refrescar=True)
                faltan = [r for r in cfg["publicacion"]["plataformas"] if r not in encontrados]
                if faltan:
                    poner("Buffer", False, f"Clave válida, pero falta conectar en Buffer: {', '.join(faltan)}.")
                else:
                    poner("Buffer", True, f"Clave válida. Canales conectados: {', '.join(encontrados)}.")
            except Exception as e:  # noqa: BLE001
                poner("Buffer", False, str(e))
        if cfg["publicacion"].get("buffer", {}).get("alojamiento", "cloudinary") == "cloudinary":
            nube = clave("CLOUDINARY_CLOUD_NAME", obligatoria=False)
            ck = clave("CLOUDINARY_API_KEY", obligatoria=False)
            cs = clave("CLOUDINARY_API_SECRET", obligatoria=False)
            if not (nube and ck and cs):
                poner("Cloudinary", False, "Faltan datos. Hacen falta el nombre de la nube, la clave y el secreto.")
            else:
                try:
                    r = requests.get(f"https://api.cloudinary.com/v1_1/{nube}/usage", auth=(ck, cs), timeout=30)
                    if r.status_code == 200:
                        poner("Cloudinary", True, "Datos válidos.")
                    elif r.status_code in (401, 403):
                        poner("Cloudinary", False, "Cloudinary rechaza la clave o el secreto.")
                    elif r.status_code == 404:
                        poner("Cloudinary", False, "No existe una nube con ese nombre. Revisa el nombre de la nube.")
                    else:
                        poner("Cloudinary", False, f"Cloudinary respondió con un error {r.status_code}.")
                except requests.RequestException as e:
                    poner("Cloudinary", False, f"No se pudo conectar con Cloudinary: {e}")
    elif modo == "upload_post":
        ok = bool(clave("UPLOAD_POST_API_KEY", obligatoria=False) and clave("UPLOAD_POST_USER", obligatoria=False))
        poner("Upload-Post", None if ok else False,
              "Datos guardados. Se comprobarán al publicar." if ok else "Faltan la clave o el nombre del perfil.")
    return res
