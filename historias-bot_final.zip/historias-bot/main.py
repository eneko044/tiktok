"""
HISTORIAS BOT — relatos de terror en primera persona, ilustrados como cómic,
publicados solos en TikTok, Instagram Reels y YouTube Shorts.

Uso:
  python main.py panel               Abre el panel de control en el navegador (y deja el bot funcionando)
  python main.py prueba --sin-apis   Vídeo de ejemplo sin gastar nada (viñetas de muestra)
  python main.py prueba              Un vídeo completo con tus APIs, sin publicarlo
  python main.py hoy                 Prepara y programa ya los vídeos que quedan hoy
  python main.py servicio            Modo 24/7 sin panel: cada día prepara y programa los vídeos solo
  python main.py historial           Lista de los últimos vídeos
  python main.py buffer              Comprueba la conexión con Buffer y qué canales tienes
"""
import argparse
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

import faulthandler

from bot.config import CARPETA_DATOS, cargar_config, configurar_logs

# Si algo se rompe por debajo de Python (p. ej. el motor de la voz), deja el rastro en pantalla y en datos/fallo_grave.log
_fallos = open(CARPETA_DATOS / "fallo_grave.log", "a", encoding="utf-8")
faulthandler.enable(file=_fallos, all_threads=True)

from bot import historial, tareas  # noqa: E402

log = configurar_logs()


def comando_prueba(cfg: dict, sin_apis: bool) -> None:
    res = tareas.generar_prueba(cfg, sin_apis)
    t = res["textos"]
    print(f"\nVídeo de prueba: {res['video']}\n\nTexto del post:\n{t['caption']}\n\nTítulo YouTube: {t['titulo_youtube']}")


def comando_historial() -> None:
    filas = historial.listado()
    if not filas:
        print("Todavía no hay vídeos en el historial.")
    for f in filas:
        nota = f"{f['puntuacion']:.1f}" if f["puntuacion"] is not None else "-"
        print(f"{f['fecha_publicacion']} {f['hora']}  nota {nota:>4}  {f['estado']:<18} {f['titulo']}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Historias Bot")
    sub = parser.add_subparsers(dest="comando", required=True)
    p = sub.add_parser("panel", help="Abre el panel de control en el navegador")
    p.add_argument("--puerto", type=int, default=8317)
    p.add_argument("--sin-navegador", action="store_true", help="No abre el navegador al arrancar")
    p = sub.add_parser("prueba", help="Genera un vídeo de prueba sin publicarlo")
    p.add_argument("--sin-apis", action="store_true", help="Usa una historia y viñetas de ejemplo (gratis)")
    sub.add_parser("hoy", help="Prepara y programa ahora los vídeos que quedan hoy")
    sub.add_parser("servicio", help="Modo 24/7 sin panel")
    sub.add_parser("historial", help="Muestra los últimos vídeos")
    sub.add_parser("buffer", help="Comprueba la conexión con Buffer y tus canales")
    args = parser.parse_args()

    cfg = cargar_config()
    try:
        if args.comando == "panel":
            from bot import panel
            panel.arrancar(args.puerto, abrir_navegador=not args.sin_navegador)
        elif args.comando == "prueba":
            comando_prueba(cfg, args.sin_apis)
        elif args.comando == "hoy":
            with tareas.CERROJO:
                tareas.preparar_dia(cfg, datetime.now(ZoneInfo(cfg["zona_horaria"])))
        elif args.comando == "servicio":
            tareas.ciclo_servicio()
        elif args.comando == "historial":
            comando_historial()
        elif args.comando == "buffer":
            from bot import buffer
            print(buffer.comprobar())
    except KeyboardInterrupt:
        print("\nParado.")
    except Exception as e:  # noqa: BLE001
        log.error("%s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
