"""Prueba solo la voz Kokoro, paso a paso, para ver dónde falla. Uso: doble clic en diagnostico_voz.bat"""
import faulthandler
import platform
import sys
import time

faulthandler.enable()
print("Python", sys.version.split()[0], platform.architecture()[0], platform.system(), platform.release())

for nombre in ("numpy", "onnxruntime", "soundfile", "kokoro_onnx"):
    try:
        modulo = __import__(nombre)
        print(f"  {nombre:12s} {getattr(modulo, '__version__', '?')}")
    except Exception as e:  # noqa: BLE001
        print(f"  {nombre:12s} NO SE PUEDE CARGAR: {e}")
        sys.exit(1)

from pathlib import Path  # noqa: E402

carpeta = Path(__file__).resolve().parent / "modelos"
for archivo in ("kokoro-v1.0.onnx", "voices-v1.0.bin"):
    ruta = carpeta / archivo
    tam = ruta.stat().st_size / 1048576 if ruta.exists() else 0
    print(f"  {archivo:18s} {'%.0f MB' % tam if tam else 'NO ESTÁ'}")
print("  (deberían ser unos 310 MB y 27 MB; si son más pequeños, la descarga se cortó: bórralos y se bajan de nuevo)")

print("\n1) Cargando el modelo...", flush=True)
from kokoro_onnx import Kokoro  # noqa: E402

t = time.time()
k = Kokoro(str(carpeta / "kokoro-v1.0.onnx"), str(carpeta / "voices-v1.0.bin"))
print(f"   OK ({time.time() - t:.1f} s)", flush=True)

print("2) Generando una frase en español...", flush=True)
t = time.time()
audio, sr = k.create("Nunca le he contado a nadie por qué dejé el turno de noche.", voice="em_alex", speed=0.88, lang="es")
print(f"   OK: {len(audio) / sr:.1f} s de audio en {time.time() - t:.1f} s", flush=True)

print("3) Guardando prueba_voz.wav...", flush=True)
import soundfile as sf  # noqa: E402

sf.write(Path(__file__).resolve().parent / "prueba_voz.wav", audio, sr)
print("   OK. La voz funciona. Escucha prueba_voz.wav")
