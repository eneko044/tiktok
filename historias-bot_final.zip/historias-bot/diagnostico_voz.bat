@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY="
for %%V in (3.13 3.12 3.14 3.11) do (
  if not defined PY (
    py -%%V -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul && set "PY=py -%%V"
  )
)
if not defined PY set "PY=python"
echo Usando: %PY%
%PY% diagnostico_voz.py
echo.
echo Codigo de salida: %errorlevel%
pause
