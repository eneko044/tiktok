"""Programación de publicaciones en Buffer (API GraphQL, incluida en el plan gratuito).

Plan gratuito: 3 canales (TikTok + Instagram + YouTube) y hasta 10 publicaciones programadas por canal.
Con 2 vídeos al día y el bot rellenando la cola cada mañana, el límite no molesta.
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

from .config import CARPETA_DATOS, clave
from .util import comprobar_respuesta, con_reintentos

log = logging.getLogger("historias")

URL_API = "https://api.buffer.com"
ARCHIVO_CANALES = CARPETA_DATOS / "buffer_canales.json"

MUTACION = """
mutation CrearPost($input: CreatePostInput!) {
  createPost(input: $input) {
    ... on PostActionSuccess { post { id dueAt } }
    ... on MutationError { message }
  }
}"""


def _graphql(consulta: str, variables: dict | None = None) -> dict:
    def _peticion():
        r = requests.post(
            URL_API,
            headers={"Authorization": f"Bearer {clave('BUFFER_API_KEY')}", "Content-Type": "application/json"},
            json={"query": consulta, "variables": variables or {}},
            timeout=120,
        )
        if r.status_code == 401:
            raise RuntimeError("La BUFFER_API_KEY no es válida. Créala en https://publish.buffer.com/settings/api")
        comprobar_respuesta(r)
        res = r.json()
        if res.get("errors"):
            raise RuntimeError("Buffer: " + "; ".join(e.get("message", "") for e in res["errors"]))
        return res["data"]
    return con_reintentos(_peticion, intentos=3, espera=15, descripcion="Petición a Buffer")


def canales(refrescar: bool = False) -> dict:
    """{'tiktok': id, 'instagram': id, 'youtube': id} de tus canales conectados en Buffer."""
    if ARCHIVO_CANALES.exists() and not refrescar:
        return json.loads(ARCHIVO_CANALES.read_text(encoding="utf-8"))
    orgs = _graphql("query { account { organizations { id name } } }")["account"]["organizations"]
    encontrados = {}
    for org in orgs:
        datos = _graphql(
            "query Canales($org: OrganizationId!) { channels(input: {organizationId: $org}) "
            "{ id name service isQueuePaused } }",
            {"org": org["id"]},
        )
        for c in datos["channels"]:
            servicio = c["service"].lower()
            if servicio in ("tiktok", "instagram", "youtube") and servicio not in encontrados:
                encontrados[servicio] = c["id"]
                if c.get("isQueuePaused"):
                    log.warning("La cola de %s (%s) está en pausa en Buffer: no se publicará.", servicio, c["name"])
    ARCHIVO_CANALES.write_text(json.dumps(encontrados, indent=2), encoding="utf-8")
    return encontrados


def _due_at(fecha: str, hora: str, zona: str) -> str:
    local = datetime.fromisoformat(f"{fecha}T{hora}").replace(tzinfo=ZoneInfo(zona))
    return local.astimezone(ZoneInfo("UTC")).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def programar(urls: dict, textos: dict, fecha: str, hora: str, zona: str, cfg_pub: dict) -> dict:
    """Crea una publicación programada por red. `urls` = {'con_musica': url, 'sin_musica': url}.
    Devuelve {red: id_del_post} y lanza error solo si fallan todas."""
    ia = bool(cfg_pub.get("etiqueta_ia", True))
    modo_tiktok = cfg_pub.get("buffer", {}).get("tiktok", "notificacion")
    ids_canal = canales()
    due = _due_at(fecha, hora, zona)
    resultados, errores = {}, {}

    for red in cfg_pub["plataformas"]:
        if red not in ids_canal:
            errores[red] = "canal no conectado en Buffer"
            continue
        entrada = {
            "channelId": ids_canal[red],
            "mode": "customScheduled",
            "dueAt": due,
            "schedulingType": "automatic",
            "aiAssisted": True,
            "text": textos["caption"],
            "assets": [{"video": {"url": urls["con_musica"], "metadata": {"thumbnailOffset": 1500}}}],
        }
        if red == "tiktok":
            entrada["metadata"] = {"tiktok": {"isAiGenerated": ia}}
            if modo_tiktok == "notificacion":
                entrada["schedulingType"] = "notification"
                entrada["assets"][0]["video"]["url"] = urls.get("sin_musica") or urls["con_musica"]
        elif red == "instagram":
            entrada["metadata"] = {"instagram": {"type": "reel", "shouldShareToFeed": True, "isAiGenerated": ia}}
        elif red == "youtube":
            entrada["text"] = textos["descripcion_youtube"]
            entrada["metadata"] = {"youtube": {
                "title": textos["titulo_youtube"], "categoryId": "24", "privacy": "public",
                "madeForKids": False, "isAiGenerated": ia, "notifySubscribers": True,
            }}
        try:
            res = _graphql(MUTACION, {"input": entrada})["createPost"]
            if res.get("message"):
                raise RuntimeError(res["message"])
            resultados[red] = res["post"]["id"]
            log.info("Buffer: %s programado para %s %s%s", red, fecha, hora,
                     " (aviso al móvil)" if entrada["schedulingType"] == "notification" else "")
        except Exception as e:  # noqa: BLE001 - que falle una red no debe tumbar las otras
            errores[red] = str(e)
            log.error("Buffer: no se pudo programar %s: %s", red, e)

    if not resultados:
        raise RuntimeError("Buffer no aceptó ninguna publicación: " + json.dumps(errores, ensure_ascii=False))
    return {"posts": resultados, "errores": errores}


def borrar(post_id: str) -> None:
    """Quita de Buffer una publicación programada."""
    res = _graphql("mutation Borrar($input: DeletePostInput!) { deletePost(input: $input) { __typename } }",
                   {"input": {"id": post_id}})["deletePost"]
    if res.get("__typename") != "DeletePostSuccess":
        raise RuntimeError(f"Buffer no dejó borrar la publicación {post_id} ({res.get('__typename')}). "
                           "Puede que ya se haya publicado: bórrala a mano en buffer.com si hace falta.")


def comprobar() -> str:
    """Comprueba la clave y muestra qué canales encuentra (comando 'python main.py buffer')."""
    encontrados = canales(refrescar=True)
    faltan = [r for r in ("tiktok", "instagram", "youtube") if r not in encontrados]
    texto = "Canales encontrados en Buffer: " + (", ".join(encontrados) or "ninguno")
    if faltan:
        texto += f"\nFaltan por conectar: {', '.join(faltan)} (en https://publish.buffer.com)"
    return texto
