"""Historial de vídeos (SQLite): evita repetir historias y lleva el estado de cada publicación."""
import json
import sqlite3
from datetime import datetime
from difflib import SequenceMatcher

from .config import CARPETA_DATOS

RUTA_DB = CARPETA_DATOS / "historial.db"


def _conexion() -> sqlite3.Connection:
    con = sqlite3.connect(RUTA_DB)
    con.row_factory = sqlite3.Row
    con.execute(
        """CREATE TABLE IF NOT EXISTS videos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            creado TEXT NOT NULL,
            fecha_publicacion TEXT,
            hora TEXT,
            prioridad INTEGER,
            puntuacion REAL,
            titulo TEXT,
            premisa TEXT,
            subgenero TEXT,
            guion TEXT,
            ruta_video TEXT,
            estado TEXT,
            detalle TEXT
        )"""
    )
    con.execute("CREATE TABLE IF NOT EXISTS lotes (fecha TEXT PRIMARY KEY, creado TEXT)")
    return con


def registrar(historia: dict, fecha: str, hora: str, prioridad: int, ruta_video: str, estado: str) -> int:
    with _conexion() as con:
        cur = con.execute(
            """INSERT INTO videos (creado, fecha_publicacion, hora, prioridad, puntuacion, titulo, premisa,
               subgenero, guion, ruta_video, estado) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                datetime.now().isoformat(timespec="seconds"), fecha, hora, prioridad,
                historia.get("puntuacion"), historia["titulo"], historia["premisa"],
                historia.get("subgenero", ""), json.dumps(historia, ensure_ascii=False), ruta_video, estado,
            ),
        )
        return cur.lastrowid


def actualizar_estado(id_video: int, estado: str, detalle: str = "") -> None:
    with _conexion() as con:
        con.execute("UPDATE videos SET estado=?, detalle=? WHERE id=?", (estado, detalle[:2000], id_video))


def recientes(n: int = 80) -> list[dict]:
    with _conexion() as con:
        filas = con.execute(
            "SELECT titulo, premisa, subgenero FROM videos ORDER BY id DESC LIMIT ?", (n,)
        ).fetchall()
    return [dict(f) for f in filas]


def subgeneros_recientes(n: int = 8) -> list[str]:
    return [f["subgenero"] for f in recientes(n) if f["subgenero"]]


def es_repetida(premisa: str, umbral: float = 0.72) -> bool:
    """True si la premisa se parece demasiado a alguna ya usada."""
    premisa = premisa.lower()
    with _conexion() as con:
        filas = con.execute("SELECT premisa FROM videos").fetchall()
    return any(SequenceMatcher(None, premisa, (f["premisa"] or "").lower()).ratio() >= umbral for f in filas)


def lote_hecho(fecha: str) -> bool:
    with _conexion() as con:
        return con.execute("SELECT 1 FROM lotes WHERE fecha=?", (fecha,)).fetchone() is not None


def marcar_lote(fecha: str) -> None:
    with _conexion() as con:
        con.execute("INSERT OR REPLACE INTO lotes VALUES (?, ?)", (fecha, datetime.now().isoformat(timespec="seconds")))


def pendientes_de_publicar() -> list[dict]:
    with _conexion() as con:
        filas = con.execute(
            "SELECT * FROM videos WHERE estado IN ('pendiente', 'error_publicacion') ORDER BY fecha_publicacion, hora"
        ).fetchall()
    return [dict(f) for f in filas]


def del_dia(fecha: str) -> list[dict]:
    """Vídeos registrados para publicarse en una fecha concreta."""
    with _conexion() as con:
        filas = con.execute(
            "SELECT * FROM videos WHERE fecha_publicacion=? AND estado != 'cancelado' ORDER BY hora", (fecha,)
        ).fetchall()
    return [dict(f) for f in filas]


def obtener(id_video: int) -> dict | None:
    with _conexion() as con:
        fila = con.execute("SELECT * FROM videos WHERE id=?", (id_video,)).fetchone()
    return dict(fila) if fila else None


def listado_completo(n: int = 100) -> list[dict]:
    with _conexion() as con:
        filas = con.execute("SELECT * FROM videos ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    return [dict(f) for f in filas]


def programados_antes_de(fecha: str) -> list[dict]:
    """Vídeos programados cuya fecha de publicación ya pasó (para limpiar el alojamiento)."""
    with _conexion() as con:
        filas = con.execute(
            "SELECT id, titulo, detalle FROM videos WHERE estado='programado' AND fecha_publicacion < ?", (fecha,)
        ).fetchall()
    return [dict(f) for f in filas]


def listado(n: int = 30) -> list[dict]:
    with _conexion() as con:
        filas = con.execute(
            "SELECT id, fecha_publicacion, hora, prioridad, puntuacion, titulo, estado FROM videos ORDER BY id DESC LIMIT ?",
            (n,),
        ).fetchall()
    return [dict(f) for f in filas]
