"""Efectos de sonido originales, generados por el propio bot (sin derechos de nadie):
golpe grave, barrido entre viñetas, latidos, interferencia y subida de tensión antes del giro.
Si pones tus propios .wav/.mp3 en la carpeta "efectos" con esos nombres (golpe, barrido, latido,
interferencia, subida), se usan los tuyos en su lugar."""
import logging
from pathlib import Path

import numpy as np
import soundfile as sf

from .config import RAIZ

log = logging.getLogger("historias")
SR = 48000
CARPETA_EFECTOS = RAIZ / "efectos"
CARPETA_EFECTOS.mkdir(exist_ok=True)
_rng = np.random.default_rng(317)


def _env(n, ataque, caida):
    t = np.arange(n) / SR
    return np.minimum(1, t / max(ataque, 1e-4)) * np.exp(-t / caida)


def _paso_bajo(x, corte):
    a = np.exp(-2 * np.pi * corte / SR)
    y = np.empty_like(x)
    acc = 0.0
    for i, v in enumerate(x):
        acc = (1 - a) * v + a * acc
        y[i] = acc
    return y


def _golpe():
    n = int(SR * 2.2)
    t = np.arange(n) / SR
    f = 55 * np.exp(-t * 2.5) + 28          # cae de tono, como un impacto de cine
    tono = np.sin(2 * np.pi * np.cumsum(f) / SR)
    ruido = _paso_bajo(_rng.normal(0, 1, n), 300) * 3
    return (tono * 0.9 + ruido * 0.4) * _env(n, 0.004, 0.55)


def _barrido():
    n = int(SR * 0.9)
    t = np.linspace(0, 1, n)
    ruido = _rng.normal(0, 1, n)
    corte = 300 + 3500 * np.sin(np.pi * t) ** 2
    y = np.empty(n)
    acc = 0.0
    for i in range(n):
        a = np.exp(-2 * np.pi * corte[i] / SR)
        acc = (1 - a) * ruido[i] + a * acc
        y[i] = acc
    return y * np.sin(np.pi * t) ** 1.5 * 1.6


def _latido():
    n = int(SR * 1.1)
    y = np.zeros(n)
    for inicio, vol in ((0.0, 1.0), (0.28, 0.7)):
        m = int(SR * 0.25)
        t = np.arange(m) / SR
        golpe = np.sin(2 * np.pi * (60 - 25 * t) * t) * np.exp(-t / 0.07) * vol
        i = int(inicio * SR)
        y[i:i + m] += golpe
    return y


def _interferencia():
    n = int(SR * 0.6)
    ruido = _rng.normal(0, 1, n)
    cortes = (np.sin(2 * np.pi * 23 * np.arange(n) / SR) > 0.2).astype(float)  # entrecortado, como una radio
    return ruido * cortes * _env(n, 0.005, 0.35) * 0.5


def _subida():
    n = int(SR * 3.0)
    t = np.linspace(0, 1, n)
    f = 80 + 500 * t ** 2
    tono = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.5 * np.sin(2 * np.pi * np.cumsum(f * 1.01) / SR)
    ruido = _paso_bajo(_rng.normal(0, 1, n), 1500)
    y = (tono * 0.5 + ruido * 0.6) * t ** 2.2
    y[-int(SR * 0.05):] *= np.linspace(1, 0, int(SR * 0.05))  # corte seco justo antes del giro
    return y


GENERADORES = {"golpe": _golpe, "barrido": _barrido, "latido": _latido,
               "interferencia": _interferencia, "subida": _subida}


def ruta(nombre: str) -> Path:
    """Devuelve el archivo del efecto (el tuyo si existe en la carpeta efectos; si no, lo genera una vez)."""
    for ext in (".wav", ".mp3", ".ogg"):
        propio = CARPETA_EFECTOS / f"{nombre}{ext}"
        if propio.exists() and not propio.name.startswith("_"):
            return propio
    generado = CARPETA_EFECTOS / f"_{nombre}.wav"
    if not generado.exists():
        y = GENERADORES[nombre]()
        y = y / (np.abs(y).max() + 1e-9) * 0.9
        sf.write(generado, np.stack([y, y], axis=1).astype(np.float32), SR)
    return generado


def plan(duraciones: list[float]) -> list[tuple[str, float, float]]:
    """(efecto, segundo, volumen) para un vídeo con estas duraciones de escena."""
    eventos = [("golpe", 0.0, 1.0), ("interferencia", 0.05, 0.5)]   # entrada fuerte: el gancho
    t = 0.0
    n = len(duraciones)
    for i, d in enumerate(duraciones[:-1]):
        t += d
        eventos.append(("barrido", max(0.0, t - 0.45), 0.35))
        if i == n // 2 - 1:
            eventos.append(("latido", t + 0.2, 0.7))                # el segundo gancho, a mitad
            eventos.append(("latido", t + 1.3, 0.6))
    inicio_final = sum(duraciones[:-1])
    eventos.append(("subida", max(0.0, inicio_final - 3.0), 0.55))   # sube la tensión antes del giro
    eventos.append(("golpe", inicio_final, 1.0))                      # y golpe en el giro
    return eventos


def pista(duraciones: list[float], total: float, destino: Path) -> Path | None:
    """Mezcla todos los efectos del vídeo en una sola pista estéreo."""
    n = int(total * SR) + SR
    mezcla = np.zeros((n, 2), dtype=np.float32)
    cache = {}
    for nombre, t, vol in plan(duraciones):
        if nombre not in cache:
            try:
                y, sr = sf.read(ruta(nombre), dtype="float32", always_2d=True)
                if sr != SR:
                    idx = np.linspace(0, len(y) - 1, int(len(y) * SR / sr)).astype(int)
                    y = y[idx]
                cache[nombre] = y[:, :2] if y.shape[1] >= 2 else np.repeat(y, 2, axis=1)
            except Exception as e:  # noqa: BLE001
                log.warning("No se pudo cargar el efecto %s: %s", nombre, e)
                cache[nombre] = None
        y = cache[nombre]
        if y is None:
            continue
        i = int(t * SR)
        fin = min(n, i + len(y))
        mezcla[i:fin] += y[:fin - i] * vol
    sf.write(destino, mezcla[: int(total * SR)], SR)
    return destino
