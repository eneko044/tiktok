"""Lectura y guardado de config.yaml desde el panel, conservando los comentarios del archivo."""
import io
import re
import shutil

import yaml
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap, CommentedSeq
from ruamel.yaml.scalarstring import DoubleQuotedScalarString, ScalarString

from .config import RAIZ

RUTA = RAIZ / "config.yaml"
HORA = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")

# Límites razonables para que un valor raro no rompa un vídeo.
LIMITES = {
    "candidatos_extra": (0, 6),
    "imagenes.tolerancia": (0, 6),
    "guion.escenas_min": (4, 30), "guion.escenas_max": (4, 30),
    "guion.palabras_min": (40, 400), "guion.palabras_max": (40, 400),
    "voz.velocidad": (0.6, 1.3), "voz.grave": (0.75, 1.05), "voz.pausa_entre_escenas": (0.0, 2.0),
    "video.transicion": (0.0, 1.5), "video.volumen_ambiente": (0.0, 1.0), "video.volumen_musica": (0.0, 1.0),
    "subtitulos.tamano": (40, 200), "subtitulos.palabras_por_grupo": (1, 6), "subtitulos.posicion_vertical": (0, 1600),
}
OPCIONES = {
    "imagenes.proveedor": {"bfl", "fal", "prueba"},
    "imagenes.modelo_bfl": {"flux-2-klein-4b", "flux-2-klein-9b", "flux-2-pro"},
    "imagenes.modelo": {"fal-ai/flux/dev", "fal-ai/flux/schnell"},
    "voz.voz": {"em_alex", "em_santa", "ef_dora"},
    "publicacion.modo": {"buffer", "upload_post", "manual"},
    "publicacion.buffer.tiktok": {"notificacion", "automatico"},
    "publicacion.buffer.alojamiento": {"cloudinary", "litterbox"},
}
REDES = {"tiktok", "instagram", "youtube"}


def leer() -> dict:
    with open(RUTA, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _plano(valor):
    """Valor sin tipos de ruamel, para comparar."""
    if isinstance(valor, dict):
        return {str(k): _plano(v) for k, v in valor.items()}
    if isinstance(valor, list):
        return [_plano(v) for v in valor]
    if isinstance(valor, ScalarString):
        return str(valor)
    return valor


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.width = 4096
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def _convertir(camino: str, original, valor):
    if camino == "publicaciones":
        filas = []
        for p in valor:
            hora = str(p.get("hora", "")).strip()
            if not HORA.match(hora):
                raise ValueError(f"La hora «{hora}» no es válida. Usa el formato 22:45.")
            prioridad = int(p.get("prioridad", 1))
            if prioridad < 1:
                raise ValueError("La prioridad tiene que ser 1 o más.")
            m = CommentedMap([("hora", DoubleQuotedScalarString(hora)), ("prioridad", prioridad)])
            m.fa.set_flow_style()
            filas.append(m)
        if not filas:
            raise ValueError("Tiene que haber al menos una hora de publicación.")
        if len({str(f["hora"]) for f in filas}) != len(filas):
            raise ValueError("Hay dos publicaciones a la misma hora.")
        seq = CommentedSeq(sorted(filas, key=lambda f: str(f["hora"])))
        return seq
    if camino == "hora_generacion":
        valor = str(valor).strip()
        if not HORA.match(valor):
            raise ValueError(f"La hora «{valor}» no es válida. Usa el formato 06:30.")
        return DoubleQuotedScalarString(valor)
    if camino in OPCIONES and valor not in OPCIONES[camino]:
        raise ValueError(f"Valor no válido para {camino}: {valor}")
    if isinstance(original, bool):
        return bool(valor)
    if isinstance(original, int):
        n = int(round(float(valor)))
    elif isinstance(original, float):
        n = float(valor)
    elif isinstance(original, list):
        lista = [str(x).strip() for x in valor if str(x).strip()]
        if camino == "publicacion.plataformas":
            if not lista or not set(lista) <= REDES:
                raise ValueError("Elige al menos una red: TikTok, Instagram o YouTube.")
        elif not lista:
            raise ValueError("La lista no puede quedar vacía.")
        return CommentedSeq(lista)
    else:
        texto = str(valor).strip()
        if not texto:
            raise ValueError(f"{camino} no puede quedar vacío.")
        return type(original)(texto) if isinstance(original, ScalarString) else texto
    if camino in LIMITES:
        bajo, alto = LIMITES[camino]
        n = min(max(n, bajo), alto)
    return n


def guardar(cambios: dict) -> dict:
    """`cambios` = {'voz.velocidad': 0.9, 'publicaciones': [...], ...}. Devuelve la configuración nueva."""
    y = _yaml()
    doc = y.load(RUTA.read_text(encoding="utf-8"))
    for camino, valor in cambios.items():
        nodo = doc
        partes = camino.split(".")
        for p in partes[:-1]:
            if p not in nodo:
                raise ValueError(f"Ajuste desconocido: {camino}")
            nodo = nodo[p]
        k = partes[-1]
        if k not in nodo:
            raise ValueError(f"Ajuste desconocido: {camino}")
        original = nodo[k]
        convertido = _convertir(camino, original, valor)
        if _plano(convertido) == _plano(original):
            continue  # sin cambios: no se toca, así se conservan formato y comentarios
        if isinstance(original, CommentedSeq) and isinstance(convertido, CommentedSeq) and original.fa.flow_style():
            convertido.fa.set_flow_style()
        nodo[k] = convertido

    g = doc["guion"]
    if g["escenas_min"] > g["escenas_max"]:
        raise ValueError("El mínimo de viñetas no puede ser mayor que el máximo.")
    if g["palabras_min"] > g["palabras_max"]:
        raise ValueError("El mínimo de palabras no puede ser mayor que el máximo.")

    salida = io.StringIO()
    y.dump(doc, salida)
    texto = salida.getvalue()
    nuevo = yaml.safe_load(texto)  # comprueba que el bot lo lee igual que antes
    for p in nuevo["publicaciones"]:
        if not isinstance(p["hora"], str):
            raise ValueError("Error interno al guardar las horas. No se ha cambiado nada.")
    shutil.copy2(RUTA, RUTA.with_suffix(".yaml.bak"))
    RUTA.write_text(texto, encoding="utf-8")
    return nuevo
