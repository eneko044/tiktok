"""Escritura de historias en primera persona, con gancho y tensión, y ranking de las mejores."""
import json
import logging
import random

import requests

from . import historial
from .config import cargar_config, clave
from .util import comprobar_respuesta, con_reintentos, slug

log = logging.getLogger("historias")

URL_OPENAI = "https://api.openai.com/v1/chat/completions"

REGLAS_COMUNES = """QUIÉN HABLA
- Narra {narrador}. Siempre en primera persona y en español de España, natural, como se habla, sin palabras rebuscadas.
- Tiene que sonar a alguien que confiesa algo que le pasó de verdad y que todavía le revuelve.

LÍMITES
- Ficción inspirada en leyendas y sucesos típicos; sin nombres ni apellidos de personas reales, sin direcciones
  reales, sin acusar a nadie real. Lugares genéricos ("un hotel de carretera en Soria") están bien.
- Inquietante, no sangriento: nada de gore, violencia explícita, menores en peligro ni autolesiones.
- No repitas ni te parezcas a estas historias ya publicadas: {usadas}"""

PROMPT_IDEAS = """Eres el jefe de guion de un canal de TikTok de relatos de terror narrados en primera persona. Los vídeos
duran algo más de un minuto y viven o mueren por sus 2 primeros segundos y por su giro final.

""" + REGLAS_COMUNES + """

TAREA: propón 6 ideas DISTINTAS entre sí sobre este tema: {subgenero}
Para cada una:
- "gancho": la primera frase del vídeo, 12 palabras como mucho. Tiene que crear una pregunta que el espectador
  NECESITE resolver: una regla que no se puede romper, un detalle imposible, una confesión que da miedo.
  Malos: "Esta es la historia más rara que me ha pasado." / "Era una noche oscura." (vagos, no prometen nada).
  Buenos: "Mi casero me dio una sola norma: no abras el armario del pasillo." / "Llevo tres años
  recibiendo el mismo audio cada 14 de marzo." / "Mi madre lleva muerta seis años. Ayer me llamó al fijo."
- "premisa": de qué va, en una frase.
- "escalada": 3 momentos que suben la tensión, cada uno peor que el anterior.
- "giro": el final, que cambie el sentido de todo lo anterior. Tiene que estar preparado por un detalle que se
  menciona al principio sin darle importancia. Evita los giros gastados ("estaba muerto", "era un sueño",
  "era yo todo el tiempo") salvo que les des una vuelta que nadie espere.
- "detalle_plantado": el detalle del principio que el giro usa.

Responde SOLO con JSON: {{"ideas": [{{"gancho": "...", "premisa": "...", "escalada": ["...", "...", "..."],
"giro": "...", "detalle_plantado": "..."}}]}}"""

PROMPT_ELEGIR = """Eres el editor más exigente de un canal de terror en TikTok. De estas ideas, elige la que más gente vería
ENTERA y volvería a ver: gancho que obliga a quedarse, escalada clara, giro que sorprende pero encaja, y que
dé para viñetas variadas (lugares, objetos, momentos distintos).

{ideas}

Responde SOLO con JSON: {{"elegida": 0, "motivo": "breve"}}"""

PROMPT_ESCRITOR = """Eres guionista de un canal de TikTok de relatos de terror narrados en primera persona, estilo confesión a
media luz. Cada vídeo dura entre un minuto y diez segundos y un minuto y medio, y se ilustra como un cómic: una
viñeta por escena.

""" + REGLAS_COMUNES + """

LA IDEA QUE TIENES QUE ESCRIBIR (tema: {subgenero})
{idea}

CÓMO ESCRIBIRLA PARA QUE ENGANCHE
1. Escena 1 = el gancho. Usa el de la idea, puliéndolo si hace falta. Nada antes: ni "Hola", ni "Os voy a contar".
2. Escena 2: contexto en una o dos frases, rápido, con un detalle concreto que haga creíble el sitio.
   Aquí, sin darle importancia, aparece el detalle plantado.
3. Escalada: cada escena tiene que hacer que la siguiente sea necesaria. Cada 3 o 4 escenas, una frase que abra
   una pregunta nueva ("Lo raro no era el ruido. Era de dónde venía."). Hacia la mitad, un segundo gancho fuerte.
4. Lo que da miedo se cuenta con detalles pequeños que están mal, no con adjetivos: la taza que estaba fría,
   los pasos que se paraban justo cuando yo me paraba, la voz que sabía mi segundo nombre.
5. Final: la última escena es una o dos frases cortas, la última de 10 palabras como mucho, y hace que el
   espectador vuelva al principio. Nada de moralejas, ni explicaciones, ni "nunca lo olvidaré".
6. Prohibido: "sentí un escalofrío", "se me heló la sangre", "de repente", "algo no iba bien", "no podía creerlo",
   "un silencio sepulcral", "mi corazón latía con fuerza", "hasta el día de hoy". Son relleno y aburren.
7. Escribe para la voz: frases cortas, puntos suspensivos (...) donde quieras una pausa, y los números y las
   horas en letra ("a las tres y diecisiete", no "3:17").

LONGITUD, MUY IMPORTANTE
- Entre {emin} y {emax} escenas y entre {pmin} y {pmax} palabras narradas en total.
- Cada escena tiene 2 o 3 frases, unas {ppe} palabras. Cuenta las palabras antes de responder, y si no llegas a
  {pmin}, añade escenas con detalles concretos (lo que oyó, lo que olía, lo que pensó). Nada de paja.

LAS VIÑETAS (en inglés)
- Cada viñeta tiene que ser claramente distinta de la anterior y de la siguiente: cambia el plano, el ángulo,
  el sujeto principal o el lugar. Nunca dos viñetas seguidas con el mismo encuadre.
- En "plano" elige uno de estos y repártelos: "extreme close-up", "close-up", "medium shot", "wide establishing shot",
  "over-the-shoulder shot", "first-person POV", "low angle shot", "high angle shot", "bird's-eye view", "silhouette shot".
- En "imagen" describe qué se ve, dónde y con qué luz. Muchas viñetas no deberían mostrar al narrador: el objeto,
  el lugar, la puerta, la ventana, la sombra, la pantalla del móvil. El narrador sale como mucho en la mitad, y nunca
  enseña la cara: de espaldas, en sombra o sus manos.

LO QUE TIENE QUE VERSE IGUAL EN TODAS LAS VIÑETAS
Las viñetas se dibujan por separado y, para que se reconozcan, antes se dibuja una ficha de cada elemento que se repite.
- En "referencias" pon siempre al protagonista, con id "protagonista". Si no hay motivo para otra cosa, es: {personaje}
- Añade como mucho otro elemento más (un objeto clave, un lugar muy concreto o un segundo personaje) solo si sale
  en 3 o más viñetas y tiene que reconocerse.
- Para cada uno: "id" corto sin espacios ni tildes; "nombre" corto en inglés, que es como lo llamarás en las
  viñetas (por ejemplo "the narrator"); y "descripcion" en inglés, concreta y visual.
- En cada escena, "aparecen" es la lista de ids que se VEN claramente en esa viñeta. Si solo se ven sus manos o es
  una vista en primera persona, no pongas al protagonista.

Responde SOLO con este JSON:
{{
  "titulo": "título interno corto",
  "premisa": "una frase que resuma la historia (para no repetirla en el futuro)",
  "subgenero": "{subgenero}",
  "referencias": [{{"id": "protagonista", "nombre": "the narrator", "descripcion": "..."}}],
  "escenas": [{{"texto": "lo que dice el narrador", "plano": "close-up", "imagen": "panel description in English", "aparecen": []}}],
  "caption": "texto del post, máximo 120 caracteres, que deje intriga sin destripar el final (sin hashtags)",
  "titulo_youtube": "título para YouTube Shorts, máximo 70 caracteres, que dé curiosidad",
  "hashtags": ["#...", "#...", "#..."]
}}
HASHTAGS: exactamente 3, en español, sobre el tema concreto de ESTA historia, como los buscaría alguien en TikTok.
Sin espacios. Nada de genéricos como #fyp, #viral o #parati, y no repitas estos, que ya se añaden siempre: {fijos}"""

PROMPT_REVISAR = """Eres el editor de guion de un canal de terror en TikTok. Revisa esta historia y devuélvela MEJORADA.
Repasa cada punto y arregla lo que no cumpla:
1. ¿La primera frase crea una pregunta que obliga a seguir viendo, en 12 palabras como mucho? Si es vaga, reescríbela.
2. ¿Cada escena hace necesaria la siguiente? Si alguna es intercambiable o solo describe, cámbiala por algo que avance.
3. ¿Hay un segundo gancho hacia la mitad?
4. ¿El giro final sorprende y está preparado por un detalle del principio? ¿La última frase es corta y deja helado?
5. ¿Hay frases hechas ("de repente", "sentí un escalofrío", "algo no iba bien"...)? Quítalas.
6. ¿Suena a alguien hablando, con frases cortas, y los números en letra?
7. Viñetas: ¿dos seguidas se parecen (mismo plano, mismo sujeto, mismo sitio)? Cambia una. ¿El narrador sale en más
   de la mitad? Sustituye algunas por el objeto, el lugar o lo que él ve. ¿"aparecen" solo incluye lo que se ve de verdad?
No cambies la longitud: entre {pmin} y {pmax} palabras narradas y entre {emin} y {emax} escenas.
Devuelve SOLO el JSON completo con exactamente el mismo formato.

{historia}"""

PROMPT_CRITICO = """Eres el editor de un canal de relatos de terror en TikTok. Puntúa cada historia del 1 al 10
pensando en cuánta gente se quedaría a verla entera: peso del gancho (primeros 2 segundos), tensión,
y si el final obliga a volver a verla. Sé exigente y no des empates si puedes evitarlo.

Historias:
{lista}

Responde SOLO con JSON: {{"puntuaciones": [{{"id": 0, "nota": 7.5, "motivo": "breve"}}]}}"""

PROMPT_AJUSTE = """Esta es una historia para un vídeo de terror narrado en primera persona. Tiene {n} palabras narradas
y necesita entre {pmin} y {pmax} (lo ideal, unas {objetivo}).
{instruccion}
Mantén el mismo gancho inicial, el mismo giro final, el mismo tono y las mismas "referencias". Cada escena nueva lleva
su "texto", su "imagen" en inglés y su lista "aparecen". En total, entre {emin} y {emax} escenas.
Devuelve SOLO el JSON completo, con exactamente el mismo formato.

{historia}"""

ALARGAR = ("Alárgala: añade escenas en medio con detalles concretos que suban la tensión (lo que oyó, lo que olía, lo que "
           "pensó en ese momento) y alarga las escenas que solo tienen una frase corta. Nada de paja ni ideas repetidas.")
ACORTAR = "Acórtala: quita lo que no aporte tensión y junta escenas si hace falta."

PERSONAJE = ("a man in his early thirties, slim build, dark grey hoodie, black jeans, short dark messy hair, "
             "always seen from behind, in silhouette or as first-person hands")


def _normalizar_referencias(h: dict) -> None:
    """Deja las referencias en un formato seguro: protagonista primero, como mucho 3, ids conocidos."""
    refs, vistos = [], set()
    for r in h.get("referencias") or []:
        if not isinstance(r, dict):
            continue
        rid = slug(str(r.get("id", "")), 30).replace("-", "_")
        if not rid or rid in vistos or not r.get("descripcion"):
            continue
        vistos.add(rid)
        refs.append({"id": rid, "nombre": str(r.get("nombre") or rid.replace("_", " ")).strip(),
                     "descripcion": str(r["descripcion"]).strip()})
    if "protagonista" not in vistos:
        refs.insert(0, {"id": "protagonista", "nombre": "the narrator", "descripcion": PERSONAJE})
    refs.sort(key=lambda r: r["id"] != "protagonista")
    refs = refs[:2]
    ids = {r["id"] for r in refs}
    for e in h["escenas"]:
        aparecen = e.get("aparecen") or []
        if not isinstance(aparecen, list):
            aparecen = []
        limpios = []
        for a in aparecen:
            a = slug(str(a), 30).replace("-", "_")
            if a in ids and a not in limpios:
                limpios.append(a)
        e["aparecen"] = limpios
    h["referencias"] = refs


def _llamar(modelo: str, prompt: str) -> dict:
    def _peticion():
        r = requests.post(
            URL_OPENAI,
            headers={"Authorization": f"Bearer {clave('OPENAI_API_KEY')}"},
            json={
                "model": modelo,
                "messages": [{"role": "user", "content": prompt}],
                "response_format": {"type": "json_object"},
            },
            timeout=180,
        )
        comprobar_respuesta(r)
        return json.loads(r.json()["choices"][0]["message"]["content"])
    return con_reintentos(_peticion, descripcion="Llamada al modelo de texto")


def _palabras(historia: dict) -> int:
    return sum(len(e["texto"].split()) for e in historia["escenas"])


def _valida(h: dict, cfg: dict) -> str | None:
    """Devuelve el motivo si la historia no sirve, o None si es válida."""
    try:
        if not cfg["escenas_min"] - 1 <= len(h["escenas"]) <= cfg["escenas_max"] + 1:
            return f"tiene {len(h['escenas'])} escenas"
        n = _palabras(h)
        if not cfg["palabras_min"] - 10 <= n <= cfg["palabras_max"] + 15:
            return f"tiene {n} palabras"
        if not all(e.get("texto") and e.get("imagen") for e in h["escenas"]):
            return "escenas incompletas"
        if historial.es_repetida(h["premisa"]):
            return "se parece a una ya publicada"
    except (KeyError, TypeError):
        return "JSON incompleto"
    return None


def _ajustar_longitud(cfg_guion: dict, h: dict) -> dict:
    """Pide al modelo que alargue o acorte la historia hasta el rango de palabras."""
    n = _palabras(h)
    prompt = PROMPT_AJUSTE.format(
        n=n, pmin=cfg_guion["palabras_min"], pmax=cfg_guion["palabras_max"],
        objetivo=(cfg_guion["palabras_min"] + cfg_guion["palabras_max"]) // 2,
        instruccion=ALARGAR if n < cfg_guion["palabras_min"] else ACORTAR,
        emin=cfg_guion["escenas_min"], emax=cfg_guion["escenas_max"],
        historia=json.dumps(h, ensure_ascii=False),
    )
    return _llamar(cfg_guion["modelo"], prompt)


def _longitud_mal(h: dict, cfg: dict) -> bool:
    try:
        n = _palabras(h)
    except (KeyError, TypeError):
        return False
    return not cfg["palabras_min"] - 10 <= n <= cfg["palabras_max"] + 15


def _elegir_idea(cfg_guion: dict, subgenero: str, comunes: dict) -> dict | None:
    """Pide 6 ideas con gancho y giro, y un editor elige la más fuerte."""
    try:
        ideas = _llamar(cfg_guion["modelo"], PROMPT_IDEAS.format(subgenero=subgenero, **comunes)).get("ideas") or []
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudieron pedir ideas (%s); se escribe directamente.", e)
        return None
    ideas = [i for i in ideas if isinstance(i, dict) and i.get("gancho")]
    if not ideas:
        return None
    lista = "\n\n".join(f"[{n}] {json.dumps(i, ensure_ascii=False)}" for n, i in enumerate(ideas))
    elegida = 0
    try:
        res = _llamar(cfg_guion["modelo"], PROMPT_ELEGIR.format(ideas=lista))
        elegida = min(max(int(res.get("elegida", 0)), 0), len(ideas) - 1)
        log.info("Idea elegida entre %d: «%s» (%s)", len(ideas), ideas[elegida]["gancho"], res.get("motivo", ""))
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudo elegir idea (%s); se usa la primera.", e)
    return ideas[elegida]


def _revisar(cfg_guion: dict, h: dict) -> dict:
    prompt = PROMPT_REVISAR.format(
        pmin=cfg_guion["palabras_min"], pmax=cfg_guion["palabras_max"],
        emin=cfg_guion["escenas_min"], emax=cfg_guion["escenas_max"], historia=json.dumps(h, ensure_ascii=False))
    try:
        revisada = _llamar(cfg_guion["modelo"], prompt)
        if revisada.get("escenas") and all(e.get("texto") and e.get("imagen") for e in revisada["escenas"]):
            revisada.setdefault("referencias", h.get("referencias"))
            log.info("Guion revisado por el editor.")
            return revisada
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudo revisar el guion (%s); se usa sin revisar.", e)
    return h


def escribir_historia(cfg_guion: dict, subgenero: str, usadas: list[dict]) -> dict:
    lista_usadas = "; ".join(f"«{u['premisa']}»" for u in usadas[:60]) or "ninguna todavía"
    comunes = {"narrador": cfg_guion["narrador"], "usadas": lista_usadas}
    escenas_medias = (cfg_guion["escenas_min"] + cfg_guion["escenas_max"]) / 2
    for intento in range(3):
        idea = _elegir_idea(cfg_guion, subgenero, comunes)
        prompt = PROMPT_ESCRITOR.format(
            subgenero=subgenero, idea=json.dumps(idea, ensure_ascii=False, indent=1) if idea else
            "(no hay idea previa: invéntala tú, con gancho fuerte y giro preparado)",
            emin=cfg_guion["escenas_min"], emax=cfg_guion["escenas_max"],
            pmin=cfg_guion["palabras_min"], pmax=cfg_guion["palabras_max"],
            ppe=round((cfg_guion["palabras_min"] + cfg_guion["palabras_max"]) / 2 / escenas_medias),
            personaje=PERSONAJE, fijos=" ".join(cargar_config()["publicacion"].get("hashtags_fijos", [])) or "ninguno",
            **comunes,
        )
        h = _llamar(cfg_guion["modelo"], prompt)
        if cfg_guion.get("revision", True) and h.get("escenas"):
            h = _revisar(cfg_guion, h)
        # Los modelos suelen quedarse cortos: en vez de tirar la historia, se le pide que la ajuste.
        for _ in range(2):
            if not _longitud_mal(h, cfg_guion):
                break
            log.info("La historia tiene %d palabras; pidiendo que la ajuste...", _palabras(h))
            try:
                ajustada = _ajustar_longitud(cfg_guion, h)
                if ajustada.get("escenas"):
                    ajustada.setdefault("referencias", h.get("referencias"))
                    h = ajustada
            except Exception as e:  # noqa: BLE001
                log.warning("No se pudo ajustar la longitud: %s", e)
                break
        problema = _valida(h, cfg_guion)
        if problema is None:
            h["subgenero"] = subgenero
            _normalizar_referencias(h)
            log.info("Referencias visuales: %s", ", ".join(r["nombre"] for r in h["referencias"]))
            return h
        log.warning("Historia descartada (%s), reescribiendo...", problema)
    raise RuntimeError(f"No se consiguió una historia válida sobre: {subgenero}")


def elegir_subgeneros(cfg_guion: dict, n: int) -> list[str]:
    """Reparte temas evitando los usados en los últimos vídeos."""
    todos = list(cfg_guion["subgeneros"])
    ultimos = set(historial.subgeneros_recientes(len(todos) // 2))
    frescos = [s for s in todos if s not in ultimos] or todos
    random.shuffle(frescos)
    elegidos = frescos[:n]
    while len(elegidos) < n:
        elegidos.append(random.choice(todos))
    return elegidos


def puntuar(cfg_guion: dict, historias: list[dict]) -> list[dict]:
    """Añade 'puntuacion' a cada historia y las devuelve ordenadas de mejor a peor."""
    lista = "\n\n".join(
        f"[id {i}] " + " ".join(e["texto"] for e in h["escenas"]) for i, h in enumerate(historias)
    )
    try:
        res = _llamar(cfg_guion["modelo"], PROMPT_CRITICO.format(lista=lista))
        notas = {int(p["id"]): float(p["nota"]) for p in res["puntuaciones"]}
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudo puntuar (%s); se mantiene el orden original.", e)
        notas = {}
    for i, h in enumerate(historias):
        h["puntuacion"] = notas.get(i, 5.0)
    return sorted(historias, key=lambda h: h["puntuacion"], reverse=True)


def generar_lote(cfg_guion: dict, cantidad: int, extra: int) -> list[dict]:
    """Escribe cantidad+extra historias distintas y devuelve las `cantidad` mejores, ordenadas."""
    usadas = historial.recientes(80)
    historias = []
    for subgenero in elegir_subgeneros(cfg_guion, cantidad + extra):
        try:
            h = escribir_historia(cfg_guion, subgenero, usadas + [{"premisa": x["premisa"]} for x in historias])
            historias.append(h)
            log.info("Historia escrita: %s (%d palabras)", h["titulo"], _palabras(h))
        except Exception as e:  # noqa: BLE001
            log.error("Fallo escribiendo sobre '%s': %s", subgenero, e)
    if not historias:
        raise RuntimeError("No se pudo escribir ninguna historia. Mira la pestaña Actividad para ver por qué.")
    if len(historias) < cantidad:
        log.warning("Solo salieron %d historias de %d: se publican las que hay, empezando por la mejor hora.",
                    len(historias), cantidad)
    return puntuar(cfg_guion, historias)[:cantidad]
