# Historias Bot

Relatos de terror en primera persona, ilustrados como un cómic, con voz grave, subtítulos animados, lluvia y música de fondo. Se programan solos en **TikTok, Instagram Reels y YouTube Shorts** a horas clave del día; la mejor historia va siempre a la última hora de la noche.

## Cómo funciona cada día

1. A las **06:30** escribe 4 historias de entre 1:10 y 1:30 (2 + 2 de reserva; cada historia decide su duración), cada una sobre un tema distinto y sin parecerse a ninguna ya publicada.
2. Un segundo paso actúa de "editor": puntúa el gancho y la tensión de cada una y se queda con las 2 mejores.
3. Reparte: la mejor a las **22:45** y la segunda a las **14:15**.
4. Para cada una genera entre 11 y 15 viñetas (FLUX), la voz (Kokoro, en tu PC), los subtítulos y monta el vídeo.
5. Lo deja **programado a su hora en Buffer** (gratis), con la etiqueta de contenido IA en las tres redes. Aunque el PC se apague después, se publica igual:
   - **Instagram Reels y YouTube Shorts**: se publican solos, con la música ya mezclada.
   - **TikTok**: a su hora te llega un aviso al móvil (app de Buffer). Lo abres en TikTok, le pones la canción desde la biblioteca de sonidos (va con licencia) y publicas. Se envía la versión sin música.

Si el PC estaba apagado a las 06:30, lo hace en cuanto se encienda, solo para las horas que aún no han pasado. Todo queda guardado en `datos/historial.db` y en `datos/bot.log`.

## Coste aproximado (2 vídeos de 1:10-1:30 al día)

| Pieza | Servicio | Al mes |
|---|---|---|
| Guiones | OpenAI GPT-5.4 mini | menos de 1 $ |
| Viñetas | fal.ai FLUX Dev (o Schnell, más barato) | unos 20 $ (unos 2,5 $ con Schnell) |
| Voz, subtítulos y montaje | tu PC | 0 € |
| Publicación en las 3 redes | Buffer (plan gratuito) + Cloudinary (plan gratuito) | 0 € |

## El panel

```
python main.py panel
```
(en Windows, doble clic en `iniciar_windows.bat`). Se abre en el navegador, en http://127.0.0.1:8317, y mientras esté abierto el bot funciona solo: no hace falta lanzar nada más.

- **Hoy**: la franja del día con la hora actual, cuándo prepara los vídeos y cuándo sale cada uno. Muestra el estado de cada publicación en TikTok, Instagram y YouTube, lo que está haciendo ahora mismo y botones para preparar los vídeos ya, generar una prueba o comprobar las claves.
- **Vídeos**: todos los vídeos hechos, con reproductor (con y sin música) y botones para copiar los textos.
- **Ajustes**: horario, historias, viñetas, voz (con botón para escucharla antes de guardar), música, subtítulos (con vista previa a escala) y publicación. Se guarda en `config.yaml` sin perder los comentarios.
- **Claves**: pega tus claves y comprueba que funcionan. Se guardan en `.env` y nunca se muestran completas.
- **Música**: arrastra tus canciones, escúchalas y quita las que no quieras.
- **Actividad**: lo que va haciendo el bot, en tiempo real.
- **Automático encendido / en pausa**: el botón de arriba a la derecha para el bot sin cerrarlo.

El panel solo es accesible desde tu propio PC. Si cierras la ventana de la terminal, el bot se para.

## Instalación

### 1. Programas necesarios
- **Python 3.11 o superior**: https://www.python.org/downloads/ (en Windows, marca "Add Python to PATH").
- **ffmpeg**
  - Windows: `winget install Gyan.FFmpeg` en una terminal, y luego cierra y abre la terminal.
  - Linux (Ubuntu): `sudo apt install ffmpeg`

### 2. Librerías
En la carpeta del proyecto:
```
pip install -r requirements.txt
```
La primera vez que genere una voz descargará el modelo Kokoro (unos 350 MB) en la carpeta `modelos`.

### 3. Prueba gratis
```
python main.py prueba --sin-apis
```
Genera un vídeo con una historia de ejemplo y viñetas de muestra en `salida/pruebas/`. Sirve para comprobar que la voz, los subtítulos y el montaje funcionan en tu PC.

### 4. Claves
Lo más fácil es abrir el panel (`python main.py panel`) e ir a la pestaña **Claves**. También puedes copiar `.env.example` como `.env` y rellenarlo a mano:
- `OPENAI_API_KEY`: https://platform.openai.com/api-keys (pon unos euros de saldo)
- `FAL_KEY`: https://fal.ai/dashboard/keys (pon unos euros de saldo)
- **Buffer** (gratis):
  1. Crea una cuenta en https://buffer.com y conecta tus 3 canales: TikTok, Instagram (tiene que ser cuenta profesional o de creador) y YouTube.
  2. Crea la clave en https://publish.buffer.com/settings/api y pégala en `BUFFER_API_KEY`.
  3. Instala la app de Buffer en el móvil, permite las notificaciones y vincula el móvil a tu canal de TikTok: es por donde te llega el aviso para publicar en TikTok.
- **Cloudinary** (gratis): Buffer necesita descargar el vídeo de una dirección pública a la hora de publicar. Crea una cuenta en https://cloudinary.com y copia de su panel (apartado *API Keys*) `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY` y `CLOUDINARY_API_SECRET`. El bot borra cada vídeo de Cloudinary al día siguiente de publicarse, así que no se llena.

Comprueba que Buffer ve tus 3 canales:
```
python main.py buffer
```

Luego prueba un vídeo real sin publicarlo:
```
python main.py prueba
```

### 5. Ponerlo en marcha 24/7
```
python main.py panel
```
(o `python main.py servicio` si lo quieres sin panel). Para que arranque solo al encender el PC:
- **Windows**: pulsa Win+R, escribe `shell:startup` y copia ahí un acceso directo a `iniciar_windows.bat`. En Configuración, ajusta la energía para que el PC no se suspenda.
- **Linux**: edita las rutas de `historias-bot.service` y ejecuta:
  ```
  sudo cp historias-bot.service /etc/systemd/system/
  sudo systemctl enable --now historias-bot
  ```

## Otros comandos
- `python main.py hoy`: prepara y programa ya los vídeos que quedan hoy.
- `python main.py historial`: lista de vídeos, nota del editor y estado.
- `python main.py buffer`: comprueba la conexión con Buffer y qué canales tienes conectados.

## Ajustes (config.yaml)
Todo esto se cambia más cómodo desde la pestaña Ajustes del panel.
- **Horas y prioridades**: el apartado `publicaciones`.
- **Voz**: `em_alex` o `em_santa` (hombre), `ef_dora` (mujer). `grave` baja el tono y `velocidad` lo hace más pausado.
- **Temas**: la lista `subgeneros`. Añade o quita los que quieras.
- **Estilo de las viñetas**: `imagenes.estilo`.
- **Ambiente propio**: mete tus .mp3 de lluvia en la carpeta `ambiente`.
- **Música de fondo**: mete un .mp3 en la carpeta `musica`. Se ralentiza, se agrava y suena lejana con crujido de disco viejo (`musica_tetrica`), y baja sola cuando habla el narrador. Usa música sin derechos: las canciones con copyright hacen que las redes silencien o reclamen el vídeo.
- **TikTok automático**: `publicacion.buffer.tiktok: automatico` lo publica solo, con la música ya mezclada en el vídeo (sin aviso al móvil).
- **Otras formas de publicar**: `publicacion.modo: upload_post` (de pago, todo automático) o `manual` (deja cada vídeo y su texto en `listos/` para subirlo tú).

## Importante
- Las historias son ficción. El bot lo indica en la descripción y activa la etiqueta de IA en las tres redes. No lo quites: las plataformas retiran el contenido realista de IA sin etiquetar.
- Las primeras semanas, revisa algún vídeo de vez en cuando. Si una historia no te gusta, cambia los temas o el estilo en `config.yaml`.
