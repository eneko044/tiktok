@echo off
REM Abre el panel de Historias Bot en el navegador y deja el bot funcionando.
REM Deja esta ventana abierta (puedes minimizarla). Si se cierra por un error, vuelve a arrancar a los 60 segundos.
cd /d "%~dp0"
python main.py panel
:bucle
echo El bot se ha detenido. Reiniciando en 60 segundos...
timeout /t 60 /nobreak >nul
python main.py panel --sin-navegador
goto bucle
