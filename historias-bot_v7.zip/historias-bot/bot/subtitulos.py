"""Subtítulos animados (formato ASS): grupos de pocas palabras con la palabra actual resaltada."""
from pathlib import Path


def _tiempo(s: float) -> str:
    s = max(0.0, s)
    h, resto = divmod(s, 3600)
    m, seg = divmod(resto, 60)
    return f"{int(h)}:{int(m):02d}:{seg:05.2f}"


def _limpiar(palabra: str) -> str:
    return palabra.replace("{", "").replace("}", "").replace("\\", "").upper()


def crear_ass(palabras: list[tuple], cfg: dict, ancho: int, alto: int, destino: Path) -> Path:
    cabecera = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {ancho}
PlayResY: {alto}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Base,{cfg['fuente']},{cfg['tamano']},{cfg['color']},&H000000FF,&H00000000,&H96000000,0,0,0,0,100,100,2,0,1,7,3,2,70,70,{cfg['posicion_vertical']},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    n = max(1, int(cfg["palabras_por_grupo"]))
    grupos, actual = [], []
    for p in palabras:
        actual.append(p)
        # Corta el grupo al llegar al máximo o al final de una frase.
        if len(actual) >= n or p[0][-1:] in ".?!…" or p[0].endswith("..."):
            grupos.append(actual)
            actual = []
    if actual:
        grupos.append(actual)

    lineas = []
    for g_idx, grupo in enumerate(grupos):
        fin_grupo = grupo[-1][2]
        if g_idx + 1 < len(grupos):
            fin_grupo = min(grupos[g_idx + 1][0][1], fin_grupo + 0.6)
        for i, (_, ini, fin) in enumerate(grupo):
            fin_evento = grupo[i + 1][1] if i + 1 < len(grupo) else fin_grupo
            texto = []
            for j, (w, _, _) in enumerate(grupo):
                w = _limpiar(w)
                if j == i:
                    texto.append(f"{{\\c{cfg['color_activo']}\\fscx108\\fscy108}}{w}{{\\r}}")
                else:
                    texto.append(w)
            entrada = "{\\fad(60,0)}" if i == 0 else ""
            lineas.append(
                f"Dialogue: 0,{_tiempo(ini)},{_tiempo(fin_evento)},Base,,0,0,0,,{entrada}{' '.join(texto)}"
            )
    destino.write_text(cabecera + "\n".join(lineas) + "\n", encoding="utf-8")
    return destino
