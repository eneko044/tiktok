"""Voz en local con Kokoro (CPU, gratis) + efecto de voz grave + tiempos de cada palabra."""
import logging
import re
from pathlib import Path

import numpy as np
import soundfile as sf

from .config import CARPETA_MODELOS
from .util import descargar, ffmpeg

log = logging.getLogger("historias")

URL_MODELOS = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
_kokoro = None


def _motor():
    global _kokoro
    if _kokoro is None:
        from kokoro_onnx import Kokoro
        for nombre in ("kokoro-v1.0.onnx", "voices-v1.0.bin"):
            ruta = CARPETA_MODELOS / nombre
            if not ruta.exists():
                log.info("Descargando modelo de voz %s (solo la primera vez)...", nombre)
                descargar(URL_MODELOS + nombre, ruta)
        _kokoro = Kokoro(str(CARPETA_MODELOS / "kokoro-v1.0.onnx"), str(CARPETA_MODELOS / "voices-v1.0.bin"))
    return _kokoro


def _tramo_con_voz(audio: np.ndarray, sr: int) -> tuple[float, float]:
    """Inicio y fin (s) de la parte con voz, ignorando silencios de los extremos."""
    ventana = int(sr * 0.02)
    n = len(audio) // ventana
    if n == 0:
        return 0.0, len(audio) / sr
    energia = np.sqrt((audio[: n * ventana].reshape(n, ventana) ** 2).mean(axis=1))
    umbral = max(energia.max() * 0.06, 1e-4)
    activos = np.where(energia > umbral)[0]
    if len(activos) == 0:
        return 0.0, len(audio) / sr
    return activos[0] * ventana / sr, (activos[-1] + 1) * ventana / sr


def _peso(palabra: str) -> float:
    """Peso aproximado de cada palabra en el tiempo: letras + pausa por puntuación."""
    p = len(re.sub(r"[^\wáéíóúüñ]", "", palabra, flags=re.I)) + 1.5
    if palabra.endswith("..."):
        p += 7
    elif palabra[-1:] in ".?!":
        p += 4
    elif palabra[-1:] in ",;:":
        p += 2
    return p


def generar_voz(escenas: list[dict], cfg: dict, carpeta: Path) -> dict:
    """Devuelve {'audio': ruta, 'duraciones': [s por escena], 'palabras': [(palabra, inicio, fin)]}."""
    k = _motor()
    trozos, duraciones, palabras = [], [], []
    t = 0.0
    sr_final = 24000
    for i, escena in enumerate(escenas):
        texto = escena["texto"].strip()
        audio, sr = k.create(texto, voice=cfg["voz"], speed=cfg["velocidad"], lang="es")
        sr_final = sr
        audio = np.asarray(audio, dtype=np.float32)
        ini, fin = _tramo_con_voz(audio, sr)
        lista = texto.split()
        pesos = np.array([_peso(w) for w in lista])
        cortes = np.concatenate([[0], np.cumsum(pesos)]) / pesos.sum() * (fin - ini) + ini
        for w, a, b in zip(lista, cortes[:-1], cortes[1:]):
            palabras.append((w, t + a, t + b))
        pausa = cfg["pausa_entre_escenas"] if i < len(escenas) - 1 else 0.9
        audio = np.concatenate([audio, np.zeros(int(sr * pausa), dtype=np.float32)])
        trozos.append(audio)
        duraciones.append(len(audio) / sr)
        t += len(audio) / sr

    crudo = carpeta / "voz_cruda.wav"
    sf.write(crudo, np.concatenate(trozos), sr_final)

    # Voz más grave sin cambiar la duración (así los subtítulos siguen cuadrando) + algo de cuerpo y sala.
    g = float(cfg.get("grave", 1.0))
    filtros = []
    if abs(g - 1.0) > 0.001:
        filtros += [f"asetrate={int(sr_final * g)}", f"aresample={sr_final}", f"atempo={1 / g:.5f}"]
    filtros += [
        "highpass=f=60",
        "equalizer=f=140:t=q:w=1.2:g=3",
        "equalizer=f=3500:t=q:w=1.5:g=-2",
        "aecho=0.8:0.6:45:0.12",
        "acompressor=threshold=0.12:ratio=3:attack=10:release=200",
    ]
    final = carpeta / "voz.wav"
    ffmpeg(["-i", crudo, "-af", ",".join(filtros), "-ar", "48000", final])
    log.info("Voz generada: %.1f s", t)
    return {"audio": final, "duraciones": duraciones, "palabras": palabras}
