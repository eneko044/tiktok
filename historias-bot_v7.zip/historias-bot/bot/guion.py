"""Escritura de historias en primera persona, con gancho y tensión, y ranking de las mejores."""
import json
import logging
import random

import requests

from . import historial
from .config import clave
from .util import comprobar_respuesta, con_reintentos

log = logging.getLogger("historias")

URL_OPENAI = "https://api.openai.com/v1/chat/completions"

PROMPT_ESCRITOR = """Eres guionista de un canal de TikTok de relatos de terror y misterio narrados en primera persona,
estilo confesión a media luz. Cada vídeo dura entre un minuto y diez segundos y un minuto y medio, y se ilustra
como un cómic: una viñeta por escena.

QUIÉN HABLA
- Narra {narrador}. Siempre en primera persona y en español de España, natural, sin palabras rebuscadas.
- Tiene que sonar a alguien contando algo que le pasó de verdad y que todavía le revuelve: detalles concretos
  (una hora exacta, un olor, un ruido, una frase que alguien dijo), nada de descripciones genéricas.

ESTRUCTURA (es lo que hace que la gente no deslice)
1. GANCHO (escena 1): la primera frase, de 12 palabras como máximo, tiene que atrapar en 2 segundos.
   Empieza por una confesión, una regla inquietante o un detalle imposible. Prohibido: "Hola", "En este vídeo",
   "Os voy a contar", "Esta historia". Ejemplos de tono: "Nunca le he contado a nadie por qué dejé ese trabajo."
   / "Mi abuela tenía una norma: a las tres, las persianas bajadas."
2. TENSIÓN (escenas centrales): frases cortas. Cada escena sube un poco más. Usa silencios con puntos
   suspensivos (...) para que la voz haga pausas. Que el oyente intuya antes que vea.
   En un minuto la gente se va a mitad: hacia la mitad del relato mete un segundo gancho, una frase que
   prometa algo peor ("Pero eso no fue lo que me hizo irme." / "Y entonces encontré la nota.").
3. GIRO FINAL (última escena): una frase corta que cambie todo o deje una pregunta abierta y obligue a
   volver a ver el vídeo. Nada de moralejas ni explicaciones.

LÍMITES
- Ficción inspirada en leyendas y sucesos típicos; sin nombres ni apellidos de personas reales, sin direcciones
  reales, sin acusar a nadie real. Lugares genéricos ("un hotel de carretera en Soria") están bien.
- Inquietante, no sangriento: nada de gore, violencia explícita, menores en peligro ni autolesiones.
- No repitas ni te parezcas a estas historias ya publicadas: {usadas}

TAREA
Escribe UNA historia nueva sobre este tema: {subgenero}
- Entre {emin} y {emax} escenas y entre {pmin} y {pmax} palabras narradas en total. La historia decide la
  longitud: si tiene recorrido, usa la parte alta; si es más directa, la baja. Nunca rellenes con paja:
  cada escena tiene que añadir un detalle nuevo o subir la tensión.
- Para cada escena, además del texto narrado, describe EN INGLÉS la viñeta (qué se ve, plano, luz).
  El narrador no muestra la cara: de espaldas, en sombra, sus manos, o lo que él ve en primera persona.
  Describe siempre al narrador igual para que parezca el mismo personaje: {personaje}

Responde SOLO con este JSON:
{{
  "titulo": "título interno corto",
  "premisa": "una frase que resuma la historia (para no repetirla en el futuro)",
  "subgenero": "{subgenero}",
  "escenas": [{{"texto": "lo que dice el narrador", "imagen": "panel description in English"}}],
  "caption": "texto del post, máximo 120 caracteres, que deje intriga (sin hashtags)",
  "titulo_youtube": "título para YouTube Shorts, máximo 70 caracteres",
  "hashtags": ["#terror", "..."]
}}
Usa entre 5 y 7 hashtags en español, mezclando generales (#historiasdeterror) y del tema concreto."""

PROMPT_CRITICO = """Eres el editor de un canal de relatos de terror en TikTok. Puntúa cada historia del 1 al 10
pensando en cuánta gente se quedaría a verla entera: peso del gancho (primeros 2 segundos), tensión,
y si el final obliga a volver a verla. Sé exigente y no des empates si puedes evitarlo.

Historias:
{lista}

Responde SOLO con JSON: {{"puntuaciones": [{{"id": 0, "nota": 7.5, "motivo": "breve"}}]}}"""

PERSONAJE = ("the narrator: a man in his early thirties, dark grey hoodie, short dark hair, "
             "always seen from behind, in silhouette or as first-person hands")


def _llamar(modelo: str, prompt: str) -> dict:
    def _peticion():
        r = requests.post(
            URL_OPENAI,
            headers={"Authorization": f"Bearer {clave('OPENAI_API_KEY')}"},
            json={
                "model": modelo,
                "messages": [{"role": "user", "content": prompt}],
                "response_format": {"type": "json_object"},
            },
            timeout=180,
        )
        comprobar_respuesta(r)
        return json.loads(r.json()["choices"][0]["message"]["content"])
    return con_reintentos(_peticion, descripcion="Llamada al modelo de texto")


def _palabras(historia: dict) -> int:
    return sum(len(e["texto"].split()) for e in historia["escenas"])


def _valida(h: dict, cfg: dict) -> str | None:
    """Devuelve el motivo si la historia no sirve, o None si es válida."""
    try:
        if not cfg["escenas_min"] - 1 <= len(h["escenas"]) <= cfg["escenas_max"] + 1:
            return f"tiene {len(h['escenas'])} escenas"
        n = _palabras(h)
        if not cfg["palabras_min"] - 10 <= n <= cfg["palabras_max"] + 15:
            return f"tiene {n} palabras"
        if not all(e.get("texto") and e.get("imagen") for e in h["escenas"]):
            return "escenas incompletas"
        if historial.es_repetida(h["premisa"]):
            return "se parece a una ya publicada"
    except (KeyError, TypeError):
        return "JSON incompleto"
    return None


def escribir_historia(cfg_guion: dict, subgenero: str, usadas: list[dict]) -> dict:
    lista_usadas = "; ".join(f"«{u['premisa']}»" for u in usadas[:60]) or "ninguna todavía"
    prompt = PROMPT_ESCRITOR.format(
        narrador=cfg_guion["narrador"], usadas=lista_usadas, subgenero=subgenero,
        emin=cfg_guion["escenas_min"], emax=cfg_guion["escenas_max"],
        pmin=cfg_guion["palabras_min"], pmax=cfg_guion["palabras_max"],
        personaje=PERSONAJE,
    )
    for intento in range(3):
        h = _llamar(cfg_guion["modelo"], prompt)
        problema = _valida(h, cfg_guion)
        if problema is None:
            h["subgenero"] = subgenero
            return h
        log.warning("Historia descartada (%s), reescribiendo...", problema)
    raise RuntimeError(f"No se consiguió una historia válida sobre: {subgenero}")


def elegir_subgeneros(cfg_guion: dict, n: int) -> list[str]:
    """Reparte temas evitando los usados en los últimos vídeos."""
    todos = list(cfg_guion["subgeneros"])
    ultimos = set(historial.subgeneros_recientes(len(todos) // 2))
    frescos = [s for s in todos if s not in ultimos] or todos
    random.shuffle(frescos)
    elegidos = frescos[:n]
    while len(elegidos) < n:
        elegidos.append(random.choice(todos))
    return elegidos


def puntuar(cfg_guion: dict, historias: list[dict]) -> list[dict]:
    """Añade 'puntuacion' a cada historia y las devuelve ordenadas de mejor a peor."""
    lista = "\n\n".join(
        f"[id {i}] " + " ".join(e["texto"] for e in h["escenas"]) for i, h in enumerate(historias)
    )
    try:
        res = _llamar(cfg_guion["modelo"], PROMPT_CRITICO.format(lista=lista))
        notas = {int(p["id"]): float(p["nota"]) for p in res["puntuaciones"]}
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudo puntuar (%s); se mantiene el orden original.", e)
        notas = {}
    for i, h in enumerate(historias):
        h["puntuacion"] = notas.get(i, 5.0)
    return sorted(historias, key=lambda h: h["puntuacion"], reverse=True)


def generar_lote(cfg_guion: dict, cantidad: int, extra: int) -> list[dict]:
    """Escribe cantidad+extra historias distintas y devuelve las `cantidad` mejores, ordenadas."""
    usadas = historial.recientes(80)
    historias = []
    for subgenero in elegir_subgeneros(cfg_guion, cantidad + extra):
        try:
            h = escribir_historia(cfg_guion, subgenero, usadas + [{"premisa": x["premisa"]} for x in historias])
            historias.append(h)
            log.info("Historia escrita: %s (%d palabras)", h["titulo"], _palabras(h))
        except Exception as e:  # noqa: BLE001
            log.error("Fallo escribiendo sobre '%s': %s", subgenero, e)
    if len(historias) < cantidad:
        raise RuntimeError(f"Solo se escribieron {len(historias)} historias de {cantidad}")
    return puntuar(cfg_guion, historias)[:cantidad]
