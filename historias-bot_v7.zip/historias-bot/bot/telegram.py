"""Envío por Telegram: a la hora de cada publicación te llegan al móvil los vídeos y los textos listos
para copiar (en Telegram, tocar un texto en formato código lo copia)."""
import html
import logging
from pathlib import Path

import requests

from .config import CARPETA_DATOS, clave
from .util import comprobar_respuesta, con_reintentos

log = logging.getLogger("historias")

ARCHIVO_CHAT = CARPETA_DATOS / "telegram_chat.txt"
LIMITE_VIDEO = 49 * 1024 * 1024  # los bots de Telegram pueden enviar archivos de hasta 50 MB


def _url(metodo: str) -> str:
    return f"https://api.telegram.org/bot{clave('TELEGRAM_BOT_TOKEN')}/{metodo}"


def _llamar(metodo: str, data: dict | None = None, files: dict | None = None, timeout: int = 60) -> dict:
    r = requests.post(_url(metodo), data=data, files=files, timeout=timeout)
    if r.status_code == 401:
        raise RuntimeError("El TELEGRAM_BOT_TOKEN no es válido. Cópialo otra vez de @BotFather.")
    comprobar_respuesta(r)
    res = r.json()
    if not res.get("ok"):
        raise RuntimeError(f"Telegram: {res.get('description')}")
    return res["result"]


def detectar_chat() -> str:
    """Busca el último chat privado que escribió al bot y lo guarda."""
    mensajes = _llamar("getUpdates", {"timeout": 0})
    for u in reversed(mensajes):
        chat = (u.get("message") or {}).get("chat") or {}
        if chat.get("type") == "private":
            ARCHIVO_CHAT.write_text(str(chat["id"]), encoding="utf-8")
            return str(chat["id"])
    raise RuntimeError("No encuentro tu chat. Abre tu bot en Telegram, pulsa Iniciar (o escríbele algo) y vuelve a probar.")


def chat_id() -> str:
    valor = clave("TELEGRAM_CHAT_ID", obligatoria=False)
    if valor:
        return valor
    if ARCHIVO_CHAT.exists():
        return ARCHIVO_CHAT.read_text(encoding="utf-8").strip()
    return detectar_chat()


def enviar_texto(texto_html: str) -> None:
    con_reintentos(
        lambda: _llamar("sendMessage", {"chat_id": chat_id(), "text": texto_html, "parse_mode": "HTML",
                                        "disable_web_page_preview": "true"}),
        descripcion="Mensaje de Telegram",
    )


def enviar_video(ruta: Path, pie_html: str) -> None:
    def _enviar():
        metodo, campo = ("sendVideo", "video") if ruta.stat().st_size <= LIMITE_VIDEO else ("sendDocument", "document")
        if metodo == "sendDocument":
            raise RuntimeError(f"{ruta.name} pesa más de 50 MB, el límite de los bots de Telegram")
        with open(ruta, "rb") as f:
            _llamar(metodo, {"chat_id": chat_id(), "caption": pie_html, "parse_mode": "HTML",
                             "supports_streaming": "true", "width": 1080, "height": 1920},
                    files={campo: (ruta.name, f, "video/mp4")}, timeout=600)
    con_reintentos(_enviar, intentos=3, espera=20, descripcion=f"Envío de {ruta.name} por Telegram")


def _codigo(texto: str) -> str:
    return f"<code>{html.escape(texto)}</code>"


def enviar_publicacion(video: Path, historia: dict, hora: str, textos: dict, cfg_tg: dict) -> str:
    """Envía la versión de TikTok (sin música) y la de Reels/Shorts (con música), cada una con sus textos."""
    titulo = html.escape(historia["titulo"])
    cancion = html.escape(cfg_tg.get("cancion_tiktok") or "la canción que quieras")
    sin_musica = video.with_name("final_sin_musica.mp4")
    if not sin_musica.exists():
        sin_musica = video

    enviar_texto(f"🎬 <b>Toca publicar · {hora}</b>\n<i>{titulo}</i>\n\nPrimero TikTok, luego Reels y Shorts. "
                 "Toca cualquier texto gris para copiarlo.")

    enviar_video(sin_musica, f"📱 <b>TikTok</b> · sin música\nAñade «{cancion}» desde Sonidos y activa "
                             "<b>Contenido generado por IA</b> en Más opciones.")
    enviar_texto(f"📱 Texto para TikTok:\n\n{_codigo(textos['caption'])}")

    enviar_video(video, "📸 <b>Instagram Reels</b> y ▶️ <b>YouTube Shorts</b> · ya lleva la música\n"
                        "Activa la etiqueta de IA en las dos.")
    enviar_texto(
        f"📸 Texto para Instagram:\n\n{_codigo(textos['caption'])}\n\n"
        f"▶️ Título para YouTube:\n\n{_codigo(textos['titulo_youtube'])}\n\n"
        f"▶️ Descripción para YouTube:\n\n{_codigo(textos['descripcion_youtube'])}"
    )
    log.info("Enviado por Telegram: %s (%s)", historia["titulo"], hora)
    return f"telegram: enviado {hora}"
