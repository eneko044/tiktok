"""Panel de control en el navegador: http://127.0.0.1:8317

Solo escucha en tu propio PC (127.0.0.1). El modo automático funciona dentro del panel,
así que basta con dejarlo abierto: no hace falta lanzar también "servicio".
"""
import json
import logging
import mimetypes
import re
import shutil
import socket
import threading
import time
import webbrowser
from collections import deque
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse
from zoneinfo import ZoneInfo

from . import ajustes, claves, historial, publicar, tareas
from .config import CARPETA_DATOS, CARPETA_FUENTES, CARPETA_MUSICA, CARPETA_SALIDA, RAIZ, cargar_config
from .util import duracion_audio

log = logging.getLogger("historias")

ARCHIVO_HTML = RAIZ / "panel" / "index.html"
ARCHIVO_ESTADO = CARPETA_DATOS / "panel.json"
CARPETA_VOZ = CARPETA_DATOS / "voz_prueba"
EXT_MUSICA = {".mp3", ".wav", ".ogg", ".m4a"}
MAX_MUSICA = 60 * 1024 * 1024

ESTADOS = {
    "pendiente": ("Esperando a programarse", "espera"),
    "programado": ("Programado", "ok"),
    "publicado": ("Publicado", "ok"),
    "listo_manual": ("Listo para subir a mano", "ok"),
    "error_publicacion": ("No se pudo programar", "error"),
}
NOMBRES_RED = {"tiktok": "TikTok", "instagram": "Instagram", "youtube": "YouTube"}


class _Lineas(logging.Handler):
    """Guarda las últimas líneas del registro para la pestaña Actividad y el progreso de la tarea."""

    def __init__(self, panel):
        super().__init__(logging.INFO)
        self.panel = panel
        self.setFormatter(logging.Formatter("%(asctime)s  %(message)s", "%H:%M:%S"))

    def emit(self, record):
        try:
            texto = self.format(record)
            self.panel.lineas.append({"nivel": record.levelname.lower(), "texto": texto})
            t = self.panel.trabajo
            if t and t["estado"] == "en_marcha":
                t["ultima"] = record.getMessage()
        except Exception:  # noqa: BLE001
            pass


class Panel:
    def __init__(self):
        self.trabajo = None
        self.recientes = deque(maxlen=8)
        self.lineas = deque(maxlen=600)
        self.parar = threading.Event()
        self.cerrojo_voz = threading.Lock()
        self.proximo_auto = 0.0
        self.automatico = self._leer_estado().get("automatico", True)
        log.addHandler(_Lineas(self))

    # ------------------------------------------------------------------ estado persistente
    def _leer_estado(self) -> dict:
        try:
            return json.loads(ARCHIVO_ESTADO.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def poner_automatico(self, activo: bool) -> None:
        self.automatico = bool(activo)
        ARCHIVO_ESTADO.write_text(json.dumps({"automatico": self.automatico}), encoding="utf-8")
        log.info("Modo automático %s.", "encendido" if activo else "en pausa")

    # ------------------------------------------------------------------ tareas en segundo plano
    def lanzar(self, clave: str, nombre: str, funcion, automatica: bool = False) -> bool:
        if not tareas.CERROJO.acquire(blocking=False):
            return False
        t = {"clave": clave, "nombre": nombre, "automatica": automatica, "estado": "en_marcha",
             "inicio": datetime.now().isoformat(timespec="seconds"), "fin": None,
             "ultima": "", "resultado": None, "error": None}
        self.trabajo = t

        def correr():
            try:
                t["resultado"] = funcion()
                t["estado"] = "ok"
            except Exception as e:  # noqa: BLE001
                log.exception("%s: %s", nombre, e)
                t["estado"] = "error"
                t["error"] = str(e)
            finally:
                t["fin"] = datetime.now().isoformat(timespec="seconds")
                self.recientes.appendleft(t)
                tareas.CERROJO.release()

        threading.Thread(target=correr, daemon=True, name=clave).start()
        return True

    def ciclo_automatico(self) -> None:
        ultimo_reintento = ultima_limpieza = 0.0
        espera = 5  # la primera comprobación, nada más abrir el panel
        while not self.parar.wait(espera):
            espera = 60
            try:
                if not self.automatico or time.time() < self.proximo_auto:
                    continue
                cfg = cargar_config()
                ahora = datetime.now(ZoneInfo(cfg["zona_horaria"]))
                if tareas.toca_preparar(cfg, ahora):
                    if tareas.faltan_claves_produccion():
                        continue  # el aviso ya aparece en el panel; se reintenta al guardar las claves
                    if self.lanzar("auto", "Preparando los vídeos de hoy",
                                   lambda: tareas.preparar_dia(cfg, ahora), True):
                        self.proximo_auto = time.time() + 15 * 60  # si falla, no lo reintenta cada minuto
                elif time.time() - ultimo_reintento > 1800:
                    ultimo_reintento = time.time()
                    if tareas.hay_reintentos(cfg):
                        self.lanzar("reintento", "Reintentando las publicaciones que fallaron",
                                    lambda: tareas.reintentar_publicaciones(cfg), True)
                elif time.time() - ultima_limpieza > 3600:
                    ultima_limpieza = time.time()
                    if historial.programados_antes_de(ahora.strftime("%Y-%m-%d")):
                        self.lanzar("limpieza", "Limpiando vídeos ya publicados",
                                    lambda: tareas.limpiar_alojamiento(cfg), True)
            except Exception as e:  # noqa: BLE001
                log.exception("Error en el modo automático: %s", e)

    # ------------------------------------------------------------------ datos para la interfaz
    @staticmethod
    def _url_salida(ruta: Path) -> str:
        return "/salida/" + ruta.relative_to(CARPETA_SALIDA).as_posix()

    def _resumen_carpeta(self, carpeta: Path) -> dict:
        r = {"id": carpeta.relative_to(CARPETA_SALIDA).as_posix(), "titulo": carpeta.name,
             "miniatura": None, "video": None, "duracion": None}
        guion_json = carpeta / "guion.json"
        if guion_json.exists():
            try:
                r["titulo"] = json.loads(guion_json.read_text(encoding="utf-8"))["titulo"]
            except (json.JSONDecodeError, KeyError):
                pass
        if (carpeta / "vineta_01.png").exists():
            r["miniatura"] = self._url_salida(carpeta / "vineta_01.png")
        if (carpeta / "final.mp4").exists():
            r["video"] = self._url_salida(carpeta / "final.mp4")
        if (carpeta / "voz.wav").exists():
            try:
                r["duracion"] = round(duracion_audio(carpeta / "voz.wav"))
            except Exception:  # noqa: BLE001
                pass
        return r

    @staticmethod
    def _redes(fila: dict) -> list[dict]:
        if fila["estado"] not in ("programado", "publicado"):
            return []
        try:
            d = json.loads(fila.get("detalle") or "{}")
        except json.JSONDecodeError:
            return []
        if not isinstance(d, dict) or "posts" not in d:
            return []
        redes = [{"red": NOMBRES_RED.get(k, k), "ok": True} for k in d["posts"]]
        redes += [{"red": NOMBRES_RED.get(k, k), "ok": False, "error": v} for k, v in d.get("errores", {}).items()]
        return redes

    def _resumen_fila(self, fila: dict) -> dict | None:
        carpeta = Path(fila["ruta_video"]).parent
        try:
            carpeta.relative_to(CARPETA_SALIDA)
        except ValueError:
            return None
        r = self._resumen_carpeta(carpeta)
        texto, tipo = ESTADOS.get(fila["estado"], (fila["estado"], "espera"))
        r.update({"tipo": "publicacion", "fecha": fila["fecha_publicacion"], "hora": fila["hora"],
                  "prioridad": fila["prioridad"], "nota": fila["puntuacion"], "estado": fila["estado"],
                  "estado_texto": texto, "estado_tipo": tipo, "redes": self._redes(fila),
                  "error": fila["detalle"] if fila["estado"] == "error_publicacion" else None})
        return r

    def estado(self) -> dict:
        cfg = cargar_config()
        zona = ZoneInfo(cfg["zona_horaria"])
        ahora = datetime.now(zona)
        fecha = ahora.strftime("%Y-%m-%d")
        del_dia = {f["hora"]: f for f in historial.del_dia(fecha)}
        mejor = min(p["prioridad"] for p in cfg["publicaciones"])
        pubs = []
        for p in sorted(cfg["publicaciones"], key=lambda x: x["hora"]):
            fila = del_dia.get(p["hora"])
            pubs.append({"hora": p["hora"], "prioridad": p["prioridad"], "estrella": p["prioridad"] == mejor,
                         "video": self._resumen_fila(fila) if fila else None})

        avisos = []
        faltan = tareas.faltan_claves_produccion()
        if faltan:
            avisos.append({"tipo": "error", "texto": f"Faltan claves para producir vídeos reales: {', '.join(faltan)}.",
                           "ir": "claves"})
        lista_claves = {c["nombre"]: c for c in claves.leer()}
        modo = cfg["publicacion"]["modo"]
        if modo == "buffer":
            faltan_b = [n for n in ("BUFFER_API_KEY", "CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET")
                        if not lista_claves[n]["configurada"]]
            if cfg["publicacion"].get("buffer", {}).get("alojamiento") == "litterbox":
                faltan_b = [n for n in faltan_b if not n.startswith("CLOUDINARY")]
            if faltan_b:
                avisos.append({"tipo": "error", "ir": "claves",
                               "texto": "Faltan claves de Buffer o Cloudinary: los vídeos se harán pero no se programarán."})
        if cfg["imagenes"]["proveedor"] == "prueba":
            avisos.append({"tipo": "aviso", "ir": "ajustes",
                           "texto": "Las viñetas están en modo de muestra: los vídeos llevarán dibujos de prueba."})
        if not self.automatico:
            avisos.append({"tipo": "aviso", "texto": "El modo automático está en pausa: hoy no se preparará nada solo."})

        hg = cfg["hora_generacion"]
        preparado = historial.lote_hecho(fecha)
        h, m = map(int, hg.split(":"))
        siguiente = ahora.replace(hour=h, minute=m, second=0, microsecond=0)
        huecos = len(tareas.huecos_pendientes(cfg, ahora))
        pendiente_hoy = not preparado and ahora >= siguiente and huecos > 0
        if preparado or ahora >= siguiente:
            siguiente += timedelta(days=1)
        return {
            "ahora": ahora.strftime("%Y-%m-%dT%H:%M"), "hora_actual": ahora.strftime("%H:%M"), "fecha": fecha,
            "automatico": self.automatico, "hora_generacion": hg, "preparado_hoy": preparado,
            "siguiente_preparacion": siguiente.strftime("%Y-%m-%dT%H:%M"),
            "pendiente_hoy": pendiente_hoy, "faltan_claves": bool(faltan),
            "huecos_libres": huecos,
            "publicaciones": pubs, "avisos": avisos, "trabajo": self.trabajo,
            "recientes": list(self.recientes)[:4],
            "modo": modo, "tiktok": cfg["publicacion"].get("buffer", {}).get("tiktok"),
            "musica": len(self._musica()),
        }

    def videos(self) -> list[dict]:
        lista, vistos = [], set()
        for fila in historial.listado_completo(120):
            r = self._resumen_fila(fila)
            if r and r["id"] not in vistos and r["video"]:
                vistos.add(r["id"])
                lista.append(r)
        pruebas = CARPETA_SALIDA / "pruebas"
        if pruebas.exists():
            for carpeta in sorted(pruebas.iterdir(), reverse=True)[:40]:
                if carpeta.is_dir() and (carpeta / "final.mp4").exists():
                    r = self._resumen_carpeta(carpeta)
                    m = re.match(r"(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})", carpeta.name)
                    r.update({"tipo": "prueba", "fecha": f"{m[1]}-{m[2]}-{m[3]}" if m else "",
                              "hora": f"{m[4]}:{m[5]}" if m else "", "estado_texto": "Prueba", "estado_tipo": "prueba"})
                    lista.append(r)
        lista.sort(key=lambda r: (r.get("fecha") or "", r.get("hora") or ""), reverse=True)
        return lista

    def video(self, ident: str) -> dict:
        carpeta = self._dentro(CARPETA_SALIDA, ident)
        if not carpeta or not carpeta.is_dir():
            raise FileNotFoundError("Ese vídeo ya no existe.")
        r = self._resumen_carpeta(carpeta)
        if (carpeta / "final_sin_musica.mp4").exists():
            r["video_sin_musica"] = self._url_salida(carpeta / "final_sin_musica.mp4")
        try:
            historia = json.loads((carpeta / "guion.json").read_text(encoding="utf-8"))
            r["textos"] = publicar.textos(historia, cargar_config()["publicacion"])
            r["guion"] = [e["texto"] for e in historia.get("escenas", [])]
        except (OSError, json.JSONDecodeError, KeyError):
            r["textos"], r["guion"] = None, []
        r["carpeta"] = str(carpeta)
        return r

    def _musica(self) -> list[dict]:
        from .montaje import _duracion_archivo
        lista = []
        for p in sorted(CARPETA_MUSICA.iterdir()):
            if p.is_file() and p.suffix.lower() in EXT_MUSICA:
                lista.append({"nombre": p.name, "mb": round(p.stat().st_size / 1048576, 1),
                              "duracion": round(_duracion_archivo(p)), "url": "/musica/" + p.name})
        return lista

    def probar_voz(self, datos: dict) -> str:
        from . import voz
        cfg = cargar_config()
        cfg_voz = dict(cfg["voz"])
        for k in ("voz", "velocidad", "grave"):
            if k in datos:
                cfg_voz[k] = datos[k] if k == "voz" else float(datos[k])
        if cfg_voz["voz"] not in ajustes.OPCIONES["voz.voz"]:
            raise ValueError("Voz desconocida.")
        texto = (datos.get("texto") or "").strip()[:300] or \
            "Nunca le he contado a nadie por qué dejé el turno de noche... Pero esa noche alguien llamó tres veces."
        with self.cerrojo_voz:
            CARPETA_VOZ.mkdir(parents=True, exist_ok=True)
            voz.generar_voz([{"texto": texto}], cfg_voz, CARPETA_VOZ)
        return f"/voz_prueba.wav?t={int(time.time())}"

    @staticmethod
    def _dentro(base: Path, relativa: str) -> Path | None:
        """Ruta dentro de `base`, o None si intenta salirse de ella."""
        destino = (base / unquote(relativa)).resolve()
        try:
            destino.relative_to(base.resolve())
        except ValueError:
            return None
        return destino


PANEL: Panel | None = None


class Manejador(BaseHTTPRequestHandler):
    server_version = "HistoriasBot"

    def log_message(self, *args):  # sin ruido en la terminal por cada petición
        pass

    # --------------------------------------------------------------- utilidades
    def _host_valido(self) -> bool:
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    def _json(self, datos, codigo: int = 200) -> None:
        cuerpo = json.dumps(datos, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(cuerpo)

    def _error(self, mensaje: str, codigo: int = 400) -> None:
        self._json({"error": mensaje}, codigo)

    def _cuerpo_json(self) -> dict:
        largo = int(self.headers.get("Content-Length") or 0)
        if largo > 2_000_000:
            raise ValueError("Petición demasiado grande.")
        return json.loads(self.rfile.read(largo) or b"{}")

    def _archivo(self, ruta: Path | None) -> None:
        if not ruta or not ruta.is_file():
            return self._error("No encontrado", 404)
        tamano = ruta.stat().st_size
        tipo = mimetypes.guess_type(ruta.name)[0] or "application/octet-stream"
        inicio, fin, codigo = 0, tamano - 1, 200
        rango = self.headers.get("Range")
        m = re.match(r"bytes=(\d*)-(\d*)", rango or "")
        if m and tamano:
            if m[1]:
                inicio = int(m[1])
                fin = int(m[2]) if m[2] else tamano - 1
            elif m[2]:
                inicio = max(0, tamano - int(m[2]))
            fin = min(fin, tamano - 1)
            if inicio > fin:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{tamano}")
                self.end_headers()
                return
            codigo = 206
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(fin - inicio + 1))
        if codigo == 206:
            self.send_header("Content-Range", f"bytes {inicio}-{fin}/{tamano}")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        try:
            with open(ruta, "rb") as f:
                f.seek(inicio)
                pendiente = fin - inicio + 1
                while pendiente > 0:
                    bloque = f.read(min(256 * 1024, pendiente))
                    if not bloque:
                        break
                    self.wfile.write(bloque)
                    pendiente -= len(bloque)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # --------------------------------------------------------------- GET
    def do_GET(self):  # noqa: N802
        if not self._host_valido():
            return self._error("Acceso no permitido", 403)
        url = urlparse(self.path)
        ruta, q = url.path, parse_qs(url.query)
        p = PANEL
        try:
            if ruta in ("/", "/index.html"):
                return self._archivo(ARCHIVO_HTML)
            if ruta == "/fuente.ttf":
                return self._archivo(CARPETA_FUENTES / "Anton-Regular.ttf")
            if ruta.startswith("/salida/"):
                return self._archivo(p._dentro(CARPETA_SALIDA, ruta[len("/salida/"):]))
            if ruta.startswith("/musica/"):
                return self._archivo(p._dentro(CARPETA_MUSICA, ruta[len("/musica/"):]))
            if ruta == "/voz_prueba.wav":
                return self._archivo(CARPETA_VOZ / "voz.wav")
            if ruta == "/api/estado":
                return self._json(p.estado())
            if ruta == "/api/videos":
                return self._json(p.videos())
            if ruta == "/api/video":
                return self._json(p.video(q.get("id", [""])[0]))
            if ruta == "/api/ajustes":
                return self._json(ajustes.leer())
            if ruta == "/api/claves":
                return self._json(claves.leer())
            if ruta == "/api/musica":
                return self._json(p._musica())
            if ruta == "/api/actividad":
                return self._json(list(p.lineas)[-400:])
            return self._error("No encontrado", 404)
        except FileNotFoundError as e:
            return self._error(str(e), 404)
        except Exception as e:  # noqa: BLE001
            log.exception("Error en el panel: %s", e)
            return self._error(str(e), 500)

    # --------------------------------------------------------------- POST
    def do_POST(self):  # noqa: N802
        # La cabecera X-Panel impide que otra web abierta en tu navegador mande órdenes al panel.
        if not self._host_valido() or self.headers.get("X-Panel") != "1":
            return self._error("Acceso no permitido", 403)
        ruta = urlparse(self.path).path
        p = PANEL
        try:
            if ruta == "/api/musica/subir":
                return self._subir_musica()
            datos = self._cuerpo_json()
            if ruta == "/api/accion":
                return self._accion(datos.get("accion"))
            if ruta == "/api/automatico":
                p.poner_automatico(datos.get("activo", True))
                return self._json({"automatico": p.automatico})
            if ruta == "/api/ajustes":
                nuevo = ajustes.guardar(datos.get("cambios", {}))
                log.info("Ajustes guardados desde el panel.")
                return self._json(nuevo)
            if ruta == "/api/claves":
                claves.guardar(datos.get("valores", {}))
                p.proximo_auto = 0.0
                log.info("Claves guardadas desde el panel.")
                return self._json(claves.leer())
            if ruta == "/api/musica/borrar":
                destino = p._dentro(CARPETA_MUSICA, datos.get("nombre", ""))
                if not destino or not destino.is_file() or destino.suffix.lower() not in EXT_MUSICA:
                    return self._error("Esa canción no está en la carpeta de música.", 404)
                destino.unlink()
                log.info("Canción quitada: %s", destino.name)
                return self._json(p._musica())
            if ruta == "/api/voz/probar":
                return self._json({"url": p.probar_voz(datos)})
            return self._error("No encontrado", 404)
        except ValueError as e:
            return self._error(str(e), 400)
        except Exception as e:  # noqa: BLE001
            log.exception("Error en el panel: %s", e)
            return self._error(str(e), 500)

    def _accion(self, accion: str):
        p = PANEL
        cfg = cargar_config()
        if accion == "prueba_gratis":
            ok = p.lanzar(accion, "Generando un vídeo de prueba gratis", lambda: tareas.generar_prueba(cfg, True))
        elif accion == "prueba":
            faltan = tareas.faltan_claves_produccion()
            if faltan:
                return self._error(f"Para un vídeo real faltan estas claves: {', '.join(faltan)}.")
            ok = p.lanzar(accion, "Generando un vídeo de prueba real", lambda: tareas.generar_prueba(cfg, False))
        elif accion == "hoy":
            faltan = tareas.faltan_claves_produccion()
            if faltan:
                return self._error(f"Para preparar vídeos reales faltan estas claves: {', '.join(faltan)}.")
            ahora = datetime.now(ZoneInfo(cfg["zona_horaria"]))
            if not tareas.huecos_pendientes(cfg, ahora):
                return self._error("Hoy ya no quedan horas de publicación libres (o ya tienen su vídeo).")
            ok = p.lanzar(accion, "Preparando los vídeos de hoy", lambda: tareas.preparar_dia(cfg, ahora))
        elif accion == "claves":
            ok = p.lanzar(accion, "Comprobando las claves", lambda: tareas.comprobar_claves(cfg))
        elif accion == "reintentar":
            ok = p.lanzar(accion, "Reintentando las publicaciones que fallaron", lambda: tareas.reintentar_publicaciones(cfg))
        else:
            return self._error("Acción desconocida.")
        if not ok:
            return self._error("Ya hay una tarea en marcha. Espera a que termine.", 409)
        return self._json({"trabajo": p.trabajo})

    def _subir_musica(self):
        nombre = Path(unquote(self.headers.get("X-Nombre", ""))).name
        nombre = re.sub(r"[^\w.\- ()áéíóúñÁÉÍÓÚÑ]", "_", nombre).strip()
        if Path(nombre).suffix.lower() not in EXT_MUSICA:
            return self._error("Sube un archivo de audio: mp3, wav, ogg o m4a.")
        largo = int(self.headers.get("Content-Length") or 0)
        if not largo or largo > MAX_MUSICA:
            return self._error("El archivo está vacío o pesa más de 60 MB.")
        destino = CARPETA_MUSICA / nombre
        temporal = destino.with_suffix(destino.suffix + ".subiendo")
        with open(temporal, "wb") as f:
            pendiente = largo
            while pendiente > 0:
                bloque = self.rfile.read(min(256 * 1024, pendiente))
                if not bloque:
                    break
                f.write(bloque)
                pendiente -= len(bloque)
        shutil.move(temporal, destino)
        log.info("Canción añadida: %s", nombre)
        return self._json(PANEL._musica())


def _puerto_ocupado(puerto: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", puerto)) == 0


def arrancar(puerto: int = 8317, abrir_navegador: bool = True) -> None:
    global PANEL
    url = f"http://127.0.0.1:{puerto}"
    if _puerto_ocupado(puerto):
        print(f"El panel ya está abierto en {url}")
        if abrir_navegador:
            webbrowser.open(url)
        return
    PANEL = Panel()
    servidor = ThreadingHTTPServer(("127.0.0.1", puerto), Manejador)
    servidor.daemon_threads = True
    threading.Thread(target=PANEL.ciclo_automatico, daemon=True, name="automatico").start()
    log.info("Panel abierto en %s (deja esta ventana abierta para que el bot siga funcionando)", url)
    if abrir_navegador:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        servidor.serve_forever(poll_interval=0.5)
    finally:
        PANEL.parar.set()
        servidor.server_close()
