"""Alojamiento temporal del vídeo en una URL pública, que es lo que necesita Buffer para descargarlo.

Buffer descarga el vídeo justo a la hora de publicar, así que la URL tiene que seguir viva hasta entonces.
- cloudinary: plan gratuito, estable (recomendado por Buffer). El bot borra cada vídeo tras publicarse.
- litterbox:  sin cuenta, pero cada archivo caduca a las 72 h.
"""
import hashlib
import logging
import time
from pathlib import Path

import requests

from .config import clave
from .util import comprobar_respuesta, con_reintentos

log = logging.getLogger("historias")


def subir(video: Path, proveedor: str, nombre: str) -> dict:
    """Devuelve {'url': ..., 'proveedor': ..., 'id': ...}."""
    if proveedor == "cloudinary":
        return _cloudinary_subir(video, nombre)
    if proveedor == "litterbox":
        return _litterbox_subir(video)
    raise RuntimeError(f"Alojamiento desconocido: {proveedor}")


def borrar(datos: dict) -> None:
    if datos.get("proveedor") == "cloudinary" and datos.get("id"):
        _cloudinary_borrar(datos["id"])


# ---------------------------------------------------------------- Cloudinary
def _firma(params: dict) -> str:
    cadena = "&".join(f"{k}={params[k]}" for k in sorted(params))
    return hashlib.sha1((cadena + clave("CLOUDINARY_API_SECRET")).encode()).hexdigest()


def _cloudinary_subir(video: Path, nombre: str) -> dict:
    nube = clave("CLOUDINARY_CLOUD_NAME")
    params = {"folder": "historias-bot", "public_id": nombre, "timestamp": int(time.time())}

    def _subir():
        params["timestamp"] = int(time.time())
        datos = {**params, "api_key": clave("CLOUDINARY_API_KEY"), "signature": _firma(params)}
        with open(video, "rb") as f:
            r = requests.post(f"https://api.cloudinary.com/v1_1/{nube}/video/upload",
                              data=datos, files={"file": (video.name, f, "video/mp4")}, timeout=600)
        comprobar_respuesta(r)
        return r.json()

    res = con_reintentos(_subir, intentos=3, espera=20, descripcion="Subida a Cloudinary")
    log.info("Vídeo alojado en Cloudinary: %s", res["secure_url"])
    return {"url": res["secure_url"], "proveedor": "cloudinary", "id": res["public_id"]}


def _cloudinary_borrar(public_id: str) -> None:
    nube = clave("CLOUDINARY_CLOUD_NAME")
    params = {"public_id": public_id, "timestamp": int(time.time())}
    datos = {**params, "api_key": clave("CLOUDINARY_API_KEY"), "signature": _firma(params)}
    r = requests.post(f"https://api.cloudinary.com/v1_1/{nube}/video/destroy", data=datos, timeout=60)
    comprobar_respuesta(r)
    log.info("Vídeo borrado de Cloudinary: %s", public_id)


# ---------------------------------------------------------------- Litterbox
def _litterbox_subir(video: Path) -> dict:
    def _subir():
        with open(video, "rb") as f:
            r = requests.post("https://litterbox.catbox.moe/resources/internals/api.php",
                              data={"reqtype": "fileupload", "time": "72h"},
                              files={"fileToUpload": (video.name, f, "video/mp4")}, timeout=600)
        comprobar_respuesta(r)
        url = r.text.strip()
        if not url.startswith("https://"):
            raise RuntimeError(f"Respuesta inesperada de Litterbox: {url[:200]}")
        return url

    url = con_reintentos(_subir, intentos=3, espera=20, descripcion="Subida a Litterbox")
    log.info("Vídeo alojado en Litterbox (72 h): %s", url)
    return {"url": url, "proveedor": "litterbox", "id": None}
