"""Montaje del vídeo: movimiento lento en cada viñeta, fundidos, ambiente, subtítulos y exportación."""
import logging
import math
import os
import random
import subprocess
from pathlib import Path

from .config import CARPETA_AMBIENTE, CARPETA_FUENTES, CARPETA_MUSICA
from .subtitulos import crear_ass
from .util import ffmpeg

log = logging.getLogger("historias")

# Movimientos de cámara (p = progreso de 0 a 1 dentro de la viñeta).
MOVIMIENTOS = [
    # zoom,                     x (0..1 del margen libre),  y (0..1 del margen libre)
    ("1.18-0.14*P", "0.5", "0.5"),          # golpe inicial: se aleja despacio
    ("1+0.10*P", "0.5", "0.45"),            # se acerca
    ("1.10", "0.5", "P"),                   # baja
    ("1.10-0.08*P", "0.5", "0.4"),          # se aleja
    ("1.10", "0.5", "1-P"),                 # sube
    ("1+0.12*P", "0.5", "0.35"),            # se acerca al tercio superior
]


def _clip_vineta(imagen: Path, salida: Path, duracion: float, mov: tuple, cfg: dict) -> None:
    fps, w, h = cfg["fps"], cfg["ancho"], cfg["alto"]
    frames = max(2, round(duracion * fps))
    p = f"(on/{frames - 1})"
    z, mx, my = (e.replace("P", p) for e in mov)
    zoompan = (
        f"zoompan=z='{z}':x='(iw-iw/zoom)*({mx})':y='(ih-ih/zoom)*({my})'"
        f":d={frames}:s={w}x{h}:fps={fps}"
    )
    ffmpeg([
        "-i", imagen,
        "-vf", f"scale={w * 2}:{h * 2}:force_original_aspect_ratio=increase,crop={w * 2}:{h * 2},{zoompan},format=yuv420p",
        "-frames:v", frames, "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", salida,
    ])


def _ambiente(duracion: float, carpeta: Path) -> Path:
    archivos = [p for p in CARPETA_AMBIENTE.iterdir() if p.suffix.lower() in (".mp3", ".wav", ".ogg", ".m4a")]
    destino = carpeta / "ambiente.wav"
    if archivos:
        ffmpeg(["-stream_loop", "-1", "-i", random.choice(archivos), "-t", f"{duracion:.2f}", "-ar", "48000", "-ac", "2", destino])
    else:
        # Lluvia lejana + zumbido grave que respira: el fondo típico de los relatos para dormir.
        ffmpeg([
            "-f", "lavfi", "-i", f"anoisesrc=color=brown:amplitude=0.5:duration={duracion:.2f}:seed={random.randint(1, 9999)}",
            "-f", "lavfi", "-i", f"sine=frequency=55:duration={duracion:.2f}",
            "-filter_complex",
            "[0:a]highpass=f=80,lowpass=f=1800,volume=0.9[lluvia];"
            "[1:a]volume=0.35,tremolo=f=0.12:d=0.7[dron];"
            "[lluvia][dron]amix=inputs=2:normalize=0,afade=t=in:d=1.5",
            "-ar", "48000", "-ac", "2", destino,
        ])
    return destino


def _musica(duracion: float, cfg: dict, carpeta: Path) -> Path | None:
    """Música de fondo de la carpeta 'musica', con efecto tétrico opcional (más lenta, grave, lejana)."""
    archivos = [p for p in CARPETA_MUSICA.iterdir() if p.suffix.lower() in (".mp3", ".wav", ".ogg", ".m4a")]
    if not archivos or float(cfg.get("volumen_musica", 0)) <= 0:
        return None
    destino = carpeta / "musica.wav"
    filtros = []
    if cfg.get("musica_tetrica", True):
        # Ralentizada y más grave, como un disco viejo, sonando lejos en otra habitación.
        filtros += [
            "aresample=48000", "asetrate=48000*0.88", "aresample=48000",
            "highpass=f=180", "lowpass=f=2600",
            "aecho=0.8:0.88:90|210|380:0.35|0.25|0.15",
            "vibrato=f=0.6:d=0.12",
        ]
    # Nivel igualado para que "volumen_musica" suene igual con cualquier canción.
    filtros += ["loudnorm=I=-20:TP=-2", "afade=t=in:d=2.5"]

    # Bucle sin cortes: la pista se encadena consigo misma con fundidos cruzados de 2 s.
    archivo = random.choice(archivos)
    largo = _duracion_archivo(archivo)
    copias = max(1, math.ceil((duracion + 4) / max(largo - 2, 3))) if largo else 1
    entradas, cadena, previo = [], [], "[0:a]"
    for i in range(copias):
        entradas += ["-i", archivo]
    for i in range(1, copias):
        cadena.append(f"{previo}[{i}:a]acrossfade=d=2:c1=tri:c2=tri[b{i}]")
        previo = f"[b{i}]"
    bucle = (";".join(cadena) + ";") if cadena else ""
    ffmpeg([
        *entradas,
        "-f", "lavfi", "-i", f"anoisesrc=color=pink:amplitude=0.012:duration={duracion:.2f}",
        "-filter_complex",
        f"{bucle}{previo}{','.join(filtros)},atrim=0:{duracion:.2f},aformat=channel_layouts=stereo[m];"
        f"[{copias}:a]highpass=f=1500,aformat=channel_layouts=stereo[crujido];"
        "[m][crujido]amix=inputs=2:normalize=0",
        "-t", f"{duracion:.2f}", "-ar", "48000", "-ac", "2", destino,
    ])
    return destino


def _duracion_archivo(ruta: Path) -> float:
    res = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(ruta)],
        capture_output=True, text=True,
    )
    try:
        return float(res.stdout.strip())
    except ValueError:
        return 0.0


def montar(vinetas: list[Path], voz: dict, cfg_video: dict, cfg_subs: dict, carpeta: Path) -> Path:
    duraciones = voz["duraciones"]
    T = float(cfg_video["transicion"])
    n = len(vinetas)

    clips = []
    for i, (img, d) in enumerate(zip(vinetas, duraciones)):
        largo = d + (T if i < n - 1 else 0)
        mov = MOVIMIENTOS[0] if i == 0 else MOVIMIENTOS[1 + (i - 1) % (len(MOVIMIENTOS) - 1)]
        clip = carpeta / f"clip_{i + 1:02d}.mp4"
        _clip_vineta(img, clip, largo, mov, cfg_video)
        clips.append(clip)

    total = sum(duraciones)
    ass = crear_ass(voz["palabras"], cfg_subs, cfg_video["ancho"], cfg_video["alto"], carpeta / "subtitulos.ass")
    ambiente = _ambiente(total, carpeta)
    musica = _musica(total, cfg_video, carpeta)

    # Fundidos entre viñetas; el último, a negro, para dar peso al giro final.
    entradas = []
    for c in clips:
        entradas += ["-i", c.name]
    partes, previo, offset = [], "[0:v]", 0.0
    for i in range(1, n):
        offset += duraciones[i - 1]
        transicion = "fadeblack" if i == n - 1 else "fade"
        etiqueta = f"[x{i}]"
        partes.append(f"{previo}[{i}:v]xfade=transition={transicion}:duration={T}:offset={offset:.3f}{etiqueta}")
        previo = etiqueta

    fuentes = os.path.relpath(CARPETA_FUENTES, carpeta).replace("\\", "/")
    partes.append(
        f"{previo}eq=contrast=1.06:saturation=0.9,vignette=PI/4.6,noise=alls=6:allf=t+u,"
        f"subtitles={ass.name}:fontsdir='{fuentes}',"
        f"fade=t=out:st={max(0.0, total - 0.7):.2f}:d=0.7,format=yuv420p[v]"
    )

    # 1) La imagen se renderiza una sola vez...
    imagen = carpeta / "imagen.mp4"
    ffmpeg([
        *entradas, "-filter_complex", ";".join(partes),
        "-map", "[v]", "-t", f"{total:.3f}",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-r", cfg_video["fps"],
        imagen.name,
    ], cwd=carpeta)

    # 2) ...y se le ponen dos sonidos: con música (Reels/Shorts) y sin música
    #    (para TikTok, donde la canción se añade desde la biblioteca de la app).
    salida = carpeta / "final.mp4"
    _mezclar(imagen, voz["audio"], ambiente, musica, total, cfg_video, salida)
    sin_musica = carpeta / "final_sin_musica.mp4"
    _mezclar(imagen, voz["audio"], ambiente, None, total, cfg_video, sin_musica)
    log.info("Vídeo montado: %s (%.1f s)", salida, total)
    return salida


def _mezclar(imagen: Path, voz: Path, ambiente: Path, musica: Path | None, total: float,
             cfg: dict, salida: Path) -> None:
    vol = float(cfg["volumen_ambiente"])
    final_audio = f"loudnorm=I=-14:TP=-1.5:LRA=11,afade=t=out:st={max(0.0, total - 0.8):.2f}:d=0.8[a]"
    if musica:
        # La música baja un poco cuando habla el narrador y recupera volumen en los silencios.
        vol_m = float(cfg["volumen_musica"])
        filtro = (
            f"[1:a]asplit=2[voz][llave];[2:a]volume={vol}[amb];[3:a]volume={vol_m}[mus];"
            f"[mus][llave]sidechaincompress=threshold=0.05:ratio=2.5:attack=40:release=700[musb];"
            f"[voz][amb][musb]amix=inputs=3:duration=first:normalize=0,{final_audio}"
        )
        extra = ["-i", musica.name]
    else:
        filtro = f"[1:a]volume=1.0[voz];[2:a]volume={vol}[amb];[voz][amb]amix=inputs=2:duration=first:normalize=0,{final_audio}"
        extra = []
    ffmpeg([
        "-i", imagen.name, "-i", voz.name, "-i", ambiente.name, *extra,
        "-filter_complex", filtro, "-map", "0:v", "-map", "[a]", "-t", f"{total:.3f}",
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart",
        salida.name,
    ], cwd=salida.parent)
