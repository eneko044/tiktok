"""Generación de viñetas: FLUX en fal.ai, o viñetas de muestra sin API para hacer pruebas."""
import logging
import random
import textwrap
from pathlib import Path

import numpy as np
import requests
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from .config import CARPETA_FUENTES, clave
from .util import comprobar_respuesta, con_reintentos, descargar

log = logging.getLogger("historias")


def generar_vinetas(escenas: list[dict], cfg: dict, carpeta: Path) -> list[Path]:
    semilla = random.randint(1, 2**31 - 1)  # misma semilla en todo el vídeo = estilo más coherente
    rutas = []
    for i, escena in enumerate(escenas, 1):
        destino = carpeta / f"vineta_{i:02d}.png"
        if cfg["proveedor"] == "fal":
            _fal(escena["imagen"], cfg, semilla, destino)
        else:
            _muestra(escena, i, len(escenas), cfg, destino)
        rutas.append(destino)
        log.info("Viñeta %d/%d lista", i, len(escenas))
    return rutas


def _fal(descripcion: str, cfg: dict, semilla: int, destino: Path) -> None:
    prompt = f"{cfg['estilo']}. {descripcion}"

    def _peticion():
        r = requests.post(
            f"https://fal.run/{cfg['modelo']}",
            headers={"Authorization": f"Key {clave('FAL_KEY')}"},
            json={
                "prompt": prompt,
                "image_size": {"width": cfg["ancho"], "height": cfg["alto"]},
                "seed": semilla,
                "num_images": 1,
                "enable_safety_checker": True,
                "output_format": "png",
            },
            timeout=300,
        )
        comprobar_respuesta(r)
        return r.json()["images"][0]["url"]

    url = con_reintentos(_peticion, descripcion="Generación de viñeta")
    descargar(url, destino)


def _muestra(escena: dict, n: int, total: int, cfg: dict, destino: Path) -> None:
    """Viñeta de prueba atmosférica (para probar el montaje sin gastar en la API de imágenes)."""
    w, h = cfg["ancho"], cfg["alto"]
    rng = np.random.default_rng(n * 7919)
    y = np.linspace(0, 1, h)[:, None]
    x = np.linspace(0, 1, w)[None, :]
    cx, cy = rng.uniform(0.3, 0.7), rng.uniform(0.25, 0.55)
    luz = np.exp(-(((x - cx) * 1.6) ** 2 + ((y - cy) * 1.1) ** 2) * 4.0)
    base = np.stack([0.05 + 0.20 * luz, 0.09 + 0.30 * luz, 0.11 + 0.28 * luz], axis=-1)
    base += rng.normal(0, 0.025, (h, w, 1))
    img = Image.fromarray((np.clip(base, 0, 1) * 255).astype("uint8"))
    d = ImageDraw.Draw(img)
    # Siluetas simples: suelo, un marco de puerta y una figura de espaldas.
    d.rectangle([0, int(h * 0.78), w, h], fill=(8, 10, 12))
    px = int(w * rng.uniform(0.15, 0.55))
    d.rectangle([px, int(h * 0.30), px + int(w * 0.30), int(h * 0.78)], outline=(20, 24, 26), width=18)
    fx = int(w * rng.uniform(0.35, 0.75))
    d.ellipse([fx - 38, int(h * 0.50), fx + 38, int(h * 0.56)], fill=(6, 7, 8))
    d.rounded_rectangle([fx - 70, int(h * 0.555), fx + 70, int(h * 0.80)], radius=40, fill=(6, 7, 8))
    img = img.filter(ImageFilter.GaussianBlur(1.2))
    d = ImageDraw.Draw(img)
    d.rectangle([14, 14, w - 15, h - 15], outline=(235, 225, 200), width=6)
    try:
        f_grande = ImageFont.truetype(str(CARPETA_FUENTES / "Anton-Regular.ttf"), 64)
        f_peque = ImageFont.truetype(str(CARPETA_FUENTES / "Anton-Regular.ttf"), 26)
    except OSError:
        f_grande = f_peque = ImageFont.load_default()
    d.text((40, 40), f"VIÑETA {n}/{total} · MUESTRA", font=f_peque, fill=(235, 200, 120))
    texto = "\n".join(textwrap.wrap("FLUX: " + escena["imagen"], 52)[:6])
    d.multiline_text((40, h - 250), texto, font=f_peque, fill=(200, 205, 205), spacing=6)
    d.text((40, 80), "AQUÍ IRÁ LA ILUSTRACIÓN", font=f_grande, fill=(240, 236, 225))
    img.save(destino)
