"""Carga de configuración, claves y rutas del proyecto."""
import logging
import os
import sys
from pathlib import Path

import yaml

RAIZ = Path(__file__).resolve().parent.parent
CARPETA_SALIDA = RAIZ / "salida"
CARPETA_LISTOS = RAIZ / "listos"
CARPETA_DATOS = RAIZ / "datos"
CARPETA_FUENTES = RAIZ / "fuentes"
CARPETA_AMBIENTE = RAIZ / "ambiente"
CARPETA_MODELOS = RAIZ / "modelos"
CARPETA_MUSICA = RAIZ / "musica"

for _c in (CARPETA_SALIDA, CARPETA_LISTOS, CARPETA_DATOS, CARPETA_AMBIENTE, CARPETA_MODELOS, CARPETA_MUSICA):
    _c.mkdir(parents=True, exist_ok=True)


def _cargar_env(ruta: Path) -> None:
    """Lee un archivo .env sencillo (CLAVE=valor) sin dependencias extra."""
    if not ruta.exists():
        return
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#") or "=" not in linea:
            continue
        clave, valor = linea.split("=", 1)
        clave, valor = clave.strip(), valor.strip().strip('"').strip("'")
        if valor and clave not in os.environ:
            os.environ[clave] = valor


def cargar_config() -> dict:
    _cargar_env(RAIZ / ".env")
    with open(RAIZ / "config.yaml", encoding="utf-8") as f:
        return yaml.safe_load(f)


def clave(nombre: str, obligatoria: bool = True) -> str:
    valor = os.environ.get(nombre, "").strip()
    if obligatoria and not valor:
        raise RuntimeError(f"Falta la clave {nombre} en el archivo .env")
    return valor


def configurar_logs() -> logging.Logger:
    log = logging.getLogger("historias")
    if log.handlers:
        return log
    log.setLevel(logging.INFO)
    formato = logging.Formatter("%(asctime)s  %(levelname)-7s %(message)s", "%Y-%m-%d %H:%M:%S")
    consola = logging.StreamHandler(sys.stdout)
    consola.setFormatter(formato)
    archivo = logging.FileHandler(CARPETA_DATOS / "bot.log", encoding="utf-8")
    archivo.setFormatter(formato)
    log.addHandler(consola)
    log.addHandler(archivo)
    return log
