"""Historia de ejemplo (~1 minuto) para probar el montaje sin gastar en la API de texto."""

HISTORIA_EJEMPLO = {
    "titulo": "Habitación 214",
    "premisa": "Un conserje de noche recibe una llamada desde una habitación precintada y se ve a sí mismo en la cámara.",
    "subgenero": "un trabajo nocturno",
    "escenas": [
        {
            "texto": "Nunca le he contado a nadie por qué dejé el turno de noche.",
            "imagen": "the narrator seen from behind sitting alone at a dim hotel reception desk at night, old CRT security monitor glowing, rain on the glass door",
        },
        {
            "texto": "Era conserje en un hotel de carretera, cerca de Soria. Cuarenta habitaciones... y casi nunca más de tres ocupadas.",
            "imagen": "wide shot of a lonely roadside hotel at night on an empty highway, flickering neon sign, fog, a single lit window",
        },
        {
            "texto": "Las noches eran largas. Café, la radio bajita... y la pantalla de las cámaras, siempre igual.",
            "imagen": "close-up of a coffee cup and a small old radio on a reception desk, a grid of grainy security camera feeds glowing behind",
        },
        {
            "texto": "A las tres y diecisiete sonó el teléfono de recepción. Habitación doscientos catorce.",
            "imagen": "close-up of an old beige desk phone ringing, a red light blinking next to the label 214, the narrator's hand hesitating above it",
        },
        {
            "texto": "Una mujer, casi susurrando, me pidió que subiera. Alguien no dejaba de mirarla desde el pasillo.",
            "imagen": "the narrator's hand holding the phone receiver to his ear, his face hidden in shadow under the hood, dim desk lamp",
        },
        {
            "texto": "Subí. El pasillo estaba vacío... y olía a humedad, como si nadie lo pisara en años.",
            "imagen": "first-person view of a long narrow hotel corridor with dim yellow wall lamps, worn carpet, doors on both sides, darkness at the far end",
        },
        {
            "texto": "La doscientos catorce estaba precintada. El jefe me lo dijo el primer día: esa no se abre.",
            "imagen": "the narrator from behind standing in front of a hotel door sealed with old tape, dust on the handle, faint light under the door",
        },
        {
            "texto": "Pero eso no fue lo que me hizo irme.",
            "imagen": "extreme close-up of the thin line of light under the sealed door, a shadow passing behind it",
        },
        {
            "texto": "Volví a recepción y miré la cámara del pasillo. Había alguien delante de esa puerta, quieto.",
            "imagen": "grainy black and white security monitor showing a hooded figure standing still in front of a door in a hotel corridor",
        },
        {
            "texto": "Llevaba mi sudadera. Era yo... Y estaba mirando a la cámara, como si supiera que lo estaba viendo.",
            "imagen": "grainy security monitor close-up, the hooded man in the corridor staring straight up at the camera, the narrator's silhouette in front of the screen",
        },
    ],
    "caption": "Dejé el turno de noche después de esto. Todavía no sé quién estaba en ese pasillo.",
    "titulo_youtube": "La llamada de la habitación 214",
    "hashtags": ["#historiasdeterror", "#relatosdeterror", "#creepypasta", "#hotel", "#turnodenoche", "#miedo"],
    "puntuacion": 8.0,
}
