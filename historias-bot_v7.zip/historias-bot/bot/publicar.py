"""Publicación en TikTok, Instagram Reels y YouTube Shorts: con Buffer (gratis), con Upload-Post
(de pago, una sola llamada) o en modo manual (deja el vídeo y su texto en la carpeta "listos")."""
import json
import logging
import shutil
from pathlib import Path

import requests

from .config import CARPETA_LISTOS, clave
from .util import comprobar_respuesta, con_reintentos, slug

log = logging.getLogger("historias")

URL_UPLOAD_POST = "https://api.upload-post.com/api/upload"


def textos(historia: dict, cfg_pub: dict) -> dict:
    hashtags = " ".join(h if h.startswith("#") else f"#{h}" for h in historia.get("hashtags", []))
    caption = f"{historia['caption']}\n\n{cfg_pub['aviso']}\n{hashtags}".strip()
    titulo_yt = historia.get("titulo_youtube") or historia["titulo"]
    if "#shorts" not in titulo_yt.lower():
        titulo_yt = f"{titulo_yt[:88]} #shorts"
    descripcion_yt = f"{historia['caption']}\n\n{cfg_pub['aviso']}\n\n{hashtags} #shorts"
    return {"caption": caption, "titulo_youtube": titulo_yt[:100], "descripcion_youtube": descripcion_yt}


def publicar(video: Path, historia: dict, fecha: str, hora: str, cfg_pub: dict, zona: str) -> str:
    """Publica (o programa) el vídeo. Devuelve un texto con el resultado para el historial."""
    t = textos(historia, cfg_pub)
    if cfg_pub["modo"] == "manual":
        return _manual(video, historia, fecha, hora, t)
    if cfg_pub["modo"] == "buffer":
        return _buffer(video, historia, fecha, hora, cfg_pub, zona, t)
    return _upload_post(video, fecha, hora, cfg_pub, zona, t)


def _buffer(video: Path, historia: dict, fecha: str, hora: str, cfg_pub: dict, zona: str, t: dict) -> str:
    from . import alojamiento, buffer

    cfg_b = cfg_pub.get("buffer", {})
    proveedor = cfg_b.get("alojamiento", "cloudinary")
    base = f"{fecha}_{hora.replace(':', '')}_{slug(historia['titulo'], 30)}"
    alojados = [alojamiento.subir(video, proveedor, base)]
    urls = {"con_musica": alojados[0]["url"]}
    sin_musica = video.with_name("final_sin_musica.mp4")
    if "tiktok" in cfg_pub["plataformas"] and cfg_b.get("tiktok", "notificacion") == "notificacion" and sin_musica.exists():
        alojados.append(alojamiento.subir(sin_musica, proveedor, base + "_tiktok"))
        urls["sin_musica"] = alojados[1]["url"]
    resultado = buffer.programar(urls, t, fecha, hora, zona, cfg_pub)
    resultado["alojamiento"] = alojados
    return json.dumps(resultado, ensure_ascii=False)


def _upload_post(video: Path, fecha: str, hora: str, cfg_pub: dict, zona: str, t: dict) -> str:
    ia = "true" if cfg_pub.get("etiqueta_ia", True) else "false"
    campos = [("user", clave("UPLOAD_POST_USER"))]
    campos += [("platform[]", p) for p in cfg_pub["plataformas"]]
    campos += [
        ("title", t["caption"]),
        ("tiktok_title", t["caption"]),
        ("instagram_title", t["caption"]),
        ("youtube_title", t["titulo_youtube"]),
        ("youtube_description", t["descripcion_youtube"]),
        # Programado: Upload-Post lo publica a su hora aunque el PC esté apagado en ese momento.
        ("scheduled_date", f"{fecha}T{hora}:00"),
        ("timezone", zona),
        # TikTok
        ("privacy_level", "PUBLIC_TO_EVERYONE"),
        ("is_aigc", ia),
        # Instagram
        ("media_type", "REELS"),
        ("share_to_feed", "true"),
        # YouTube
        ("privacyStatus", "public"),
        ("containsSyntheticMedia", ia),
        ("selfDeclaredMadeForKids", "false"),
        ("categoryId", "24"),  # Entretenimiento
        ("defaultLanguage", "es"),
        ("defaultAudioLanguage", "es"),
        # Las tres
        ("is_ai_generated", ia),
    ]

    def _subir():
        with open(video, "rb") as f:
            r = requests.post(
                URL_UPLOAD_POST,
                headers={"Authorization": f"Apikey {clave('UPLOAD_POST_API_KEY')}"},
                data=campos,
                files={"video": (video.name, f, "video/mp4")},
                timeout=600,
            )
        comprobar_respuesta(r)
        respuesta = r.json()
        if respuesta.get("success") is False:
            raise RuntimeError(respuesta.get("error") or json.dumps(respuesta)[:400])
        return respuesta

    respuesta = con_reintentos(_subir, intentos=3, espera=30, descripcion="Subida a Upload-Post")
    log.info("Programado en %s para %s %s", ", ".join(cfg_pub["plataformas"]), fecha, hora)
    return json.dumps(respuesta, ensure_ascii=False)[:1500]


def _manual(video: Path, historia: dict, fecha: str, hora: str, t: dict) -> str:
    carpeta = CARPETA_LISTOS / fecha
    carpeta.mkdir(parents=True, exist_ok=True)
    base = f"{hora.replace(':', '')}_{slug(historia['titulo'])}"
    destino = carpeta / f"{base}.mp4"
    shutil.copy2(video, destino)
    (carpeta / f"{base}.txt").write_text(
        f"PUBLICAR A LAS {hora}\n\n"
        f"--- TikTok / Instagram ---\n{t['caption']}\n\n"
        f"--- YouTube Shorts ---\nTítulo: {t['titulo_youtube']}\n\n{t['descripcion_youtube']}\n\n"
        "Recuerda activar la etiqueta de contenido generado con IA en cada red.\n",
        encoding="utf-8",
    )
    log.info("Vídeo listo para publicar a mano: %s", destino)
    return f"manual: {destino}"
